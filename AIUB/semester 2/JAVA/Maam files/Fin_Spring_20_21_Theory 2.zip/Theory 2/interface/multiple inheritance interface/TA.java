import java.lang.*;
public class TA implements IFaculty,IStudent
{
	public void displayInfo()
	{
		System.out.println("I am your Teacher and I am also a masters student");
	}
}