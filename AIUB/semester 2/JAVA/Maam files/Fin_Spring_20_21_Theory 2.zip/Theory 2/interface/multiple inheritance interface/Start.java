import java.lang.*;
public class Start
{
	public static void main(String args[])
	{
		TA t1=new TA();
		t1.displayInfo();
		Faculty.disp();
	}
}