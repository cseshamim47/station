import java.lang.*;
public interface IStudent
{
	public void displayInfo();
	
}