import java.lang.*;
public interface IFaculty
{
	
	public void displayInfo();
	public static void disp()
	{
		System.out.println("Inside disp");
	}
	
	
}