import java.lang.*;
public interface Shape
{
	
	public void displayArea();
	
}