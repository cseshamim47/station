import java.lang.*;
public class Start
{
	public static void main(String args[])
	{
		Rectangle r1=new Rectangle();
		r1.displayArea();
		Triangle t1=new Triangle();
		t1.displayArea();
		Shape s1=new Rectangle();
		s1.displayArea();
		
	}
}