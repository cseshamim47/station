import java.lang.*;
public class Rectangle implements Shape
{
	public void displayArea()
	{
		System.out.println("Inside Rectangle area display");
	}
}