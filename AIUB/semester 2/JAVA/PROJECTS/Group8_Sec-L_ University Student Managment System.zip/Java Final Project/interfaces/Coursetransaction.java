package interfaces;
import java.lang.*;
import classes.*;
public interface Coursetransaction {
	public abstract void adding(int quantity);
	public abstract void dropping(int quantity);
}
