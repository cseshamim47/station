import java.util.Scanner;
import Module1.*;
import Module2.*;

public class Main 
{

    public static void main(String[] args) 
	{
         Scanner obj=new Scanner(System.in);

         int choice =0;
 
         while(choice !=4)
		 {

             System.out.println("Enter 1- for Admin \nEnter 2- for Customer");
             choice =obj.nextInt();

             if (choice == 1) 
			 {
			     System.out.print("Enter your Name: ");
				 obj.nextLine();
                 String adName=obj.nextLine();
	   
	             System.out.print("Enter your Password: ");
                 String adId=obj.nextLine();
				 
				 Person a1= new Admin(adName,adId); // Dynamic Polymorphism 
	      
		         System.out.println("Admin Name: "+a1.getName());
		         System.out.println("Admin Password: "+a1.getId());
				 
				 if(a1.getId().equals("2345")||a1.getId().equals("2346"))
				 {
					 System.out.println("You can not add more than 5 books in one time");
				     System.out.print("How many book you Add: ");
				     String size=obj.nextLine();
				     Admin a2=new Admin();
				 
				     System.out.print("Enter Book Name: ");
                     String bName1=obj.nextLine();
	                 System.out.print("Enter Book Id: ");
                     String bId1=obj.nextLine();
				 
				     System.out.print("Enter Book Name: ");
                     String bName2=obj.nextLine();
	                 System.out.print("Enter Book Id: ");
                     String bId2=obj.nextLine();
				 
				     System.out.print("Enter Book Name: ");
                     String bName3=obj.nextLine();
	                 System.out.print("Enter Book Id: ");
                     String bId3=obj.nextLine();
				 
				     System.out.print("Enter Book Name: ");
                     String bName4=obj.nextLine();
	                 System.out.print("Enter Book Id: ");
                     String bId4=obj.nextLine();
				 
				     System.out.print("Enter Book Name: ");
                     String bName5=obj.nextLine();
	                 System.out.print("Enter Book Id: ");
                     String bId5=obj.nextLine();
				 
				
				     /*Book b1 = new Book(bName1,bId1);
		             Book b2 = new Book(bName2,bId2);
				     Book b3 = new Book(bName3,bId3);
				     Book b4 = new Book(bName4,bId4);
				     Book b5 = new Book(bName5,bId5);*/
				 
		             Book bo[]=new Book[5];
				     bo[0]=new Book(bName1,bId1);
				     bo[1]=new Book(bName2,bId2);
				     bo[2]=new Book(bName3,bId3);
				    // bo[3]=b4;
		             //bo[4]=b5;
				 
				     a2.addBook(bo);
				     a2.getBook();
				 }
				 else
				 {
					 System.out.print("You'r Password is not correcect. Please try Again\n");
				 }
			 }
			
			 else if (choice == 2)
			 
			 {
				 int choice1 =0;
                 
				 while(choice1 !=4)
		         {
					 System.out.print("********  Welcome to our shop  **********\n\n");
                     System.out.println("Enter 1- for Text Book \nEnter 2- for Story Book \nEnter 3- for Science Fiction Book");
                     choice1=obj.nextInt();
					 if(choice1==1)
					 {
						 TextBook t1= new TextBook();
						 t1.showAll();
						 continue;
					 }
					 if(choice1==2)
					 {
						 StoryBooks S1= new StoryBooks();
						 S1.showAll();
						 continue;
					 }
					 if(choice1==3)
					 {
						 StoryBooks S1= new StoryBooks();
						 S1.showAll();
						 continue;
					 }
					 
					  
				 }
             
             }

            /*else if(choice ==2){
                Module2 obj2=new Module2();

                obj2.chemistry();
                obj2.physics();
                obj2.biology();

            }
            }*/


         }

     }
}

