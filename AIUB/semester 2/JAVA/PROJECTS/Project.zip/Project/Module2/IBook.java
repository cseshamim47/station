package Module2;
import java.lang.*;
public interface IBook 
{
	 public void showAll();
}