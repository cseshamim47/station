import A.*;

class Start
{
    public static void main(String[] args) throws Exception
    {
        System.out.println("#####################################");
        System.out.println();
        System.out.println("WELCOME TO  CO-OPERATIVE  BANK ");
        System.out.println();
        System.out.println("#####################################");
        System.out.println();
        Banking ob = new Banking();
        ob.showMenu();
    }
}