import java.lang.*;

public class Account{
	static int count = 0;
	String accountName;
	double balance;
	Account(){
		count++;
	}
	Account(String an,double b){
		accountName = an;
		balance = b;
	}
	void deposit(double am){
		balance += am;
	}
	void withdraw(double am){
		balance -= am;
	}
	void displayInfo(){
		System.out.println("Account name: "+accountName);
		System.out.println("Account balance: "+balance);
		System.out.println("Objects Created : "+count);
	}
	
	public static void main(String[] args){
		Account ac1 = new Account();
		Account ac2 = new Account();
		Account ac3 = new Account();
		Account ac4 = new Account();
		Account ac5 = new Account();
		
		Account ac1p = new Account("Md Shamim Ahmed", 1000.54);
		ac1p.deposit(500);
		ac1p.withdraw(300);
		ac1p.displayInfo();
	}
}