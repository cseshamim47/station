public class Calculator
{
	double num1;
	double num2;
	
	Calculator(){}
	
	Calculator(double n1,double n2)
	{
		num1 = n1;
		num2 = n2;
	}
	
	double add(double n1,double n2)
	{
		return n1+n2;
	}
	
	double sub(double n1,double n2)
	{
		if(n1>n2) return n1-n2;
		else return n2-n1;
	}
	
	double div(double n1,double n2)
	{
		return n1/n2;
	}
	
	double mult(double n1,double n2)
	{
		return n1*n2;
	}
	
	void display()
	{
		System.out.println("Number 1 : "+num1);
		System.out.println("Number 2 : "+num2);
	}
	
	public static void main(String args[])
	{
		Calculator empty = new Calculator();
		Calculator obj1 = new Calculator(10.5,20.3);
		obj1.display();
		System.out.println("Sum : "+obj1.add(10.5,20.3));
		System.out.println("Subtraction : "+obj1.sub(10.5,20.3));
		System.out.println("Division : "+obj1.div(10.5,20.3));
		System.out.println("Multiplication : "+obj1.mult(10.5,20.3));
		
	}
	
}




