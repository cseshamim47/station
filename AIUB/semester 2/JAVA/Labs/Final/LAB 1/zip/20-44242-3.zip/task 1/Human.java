public class Human {
    private String type;
    Human(){}
    Human(String type){
        this.type = type;
    }
    public void setType(String type){
        this.type = type;
    }
    public String getType(){
        return type;
    }

}
