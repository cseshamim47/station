﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperShopManegementSystem;

namespace SuperShopManagementSystem
{
    public partial class Employee : Form
    {
        private DataAccess Da { get; set; }
        private string UserName { get; set; }
        private Login Login { get; }
        public Employee()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulateGridView();
        }
        public Employee(string userName, Login login)
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.UserName = userName;
            this.Login = login;
        }
        private void Employee_Load(object sender, EventArgs e)
        {
            //this.tabControl.SelectTab(2);
            this.cmbCategory.SelectedIndex = 0;


            string query = "select * from UserInformation where UserId = '" + this.UserName + "';";

            var ds = this.Da.ExecuteQueryTable(query);
            this.txtUserName.Text = ds.Rows[0][1].ToString();
            this.txtUserId.Text = ds.Rows[0][0].ToString();
            this.txtPassword.Text = ds.Rows[0][8].ToString();
            this.txtPhone.Text = ds.Rows[0][6].ToString();
            this.dtpDOB.Text = ds.Rows[0][4].ToString();


            /// dgvProducts
            dgvProducts.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(66)))), ((int)(((byte)(35)))));
            dgvProducts.DefaultCellStyle.SelectionForeColor = Color.White;

           
        }

        private void PopulateGridView(string sql = "select * from ProductInformation;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvCart.AutoGenerateColumns = false;
            this.dgvProducts.AutoGenerateColumns = false;
            if (ds.Tables[0].Rows.Count > 0)
            {
                this.dgvProducts.DataSource = ds.Tables[0];
            }
        }


        private void btnHome_Click(object sender, EventArgs e)
        {
            this.tabControl.SelectTab(0);
            this.resetHome();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            this.tabControl.SelectTab(1);
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            if(this.btnEye.Enabled == true)
            {
                this.ToggleReadOnly();
                this.btnEye_Click(sender, e);
            }
            this.tabControl.SelectTab(2);
        }


        private void btnEdit_Click(object sender, EventArgs e)
        {
            this.ToggleReadOnly();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string query = "update UserInformation" +
                " set UserName = '" + this.txtUserName.Text +
                "', UserId = '" + this.txtUserId.Text +
                "', Password = '" + this.txtPassword.Text +
                "', DateOfBirth = '" + this.dtpDOB.Text +
                "' where UserId = '" + this.UserName + "'";
            var rowCount = this.Da.ExecuteDMLQuery(query);
            if (rowCount == 1)
            {
                this.btnEye_Click(sender, new EventArgs());
                MessageBox.Show("Data updated successfully");
            }
            else
                MessageBox.Show("Data upgradation failed");
            this.ToggleReadOnly();
        }

        int eye = 1;
        private void btnEye_Click(object sender, EventArgs e)
        {
            this.pnlRight.Focus();
            try
            {
                eye *= -1;
                if (eye < 0)
                {
                    string filePath = System.IO.Path.GetFullPath(@"..\..\Resources\002-view.png");
                    Bitmap eyeOpen = new Bitmap(filePath);
                    this.btnEye.Image = eyeOpen;
                    this.txtPassword.UseSystemPasswordChar = false;
                }
                else
                {
                    string filePath = System.IO.Path.GetFullPath(@"..\..\Resources\001-hide.png");
                    Bitmap eyeClose = new Bitmap(filePath);
                    this.btnEye.Image = eyeClose;
                    this.txtPassword.UseSystemPasswordChar = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void ToggleReadOnly()
        {
            this.btnEdit.Enabled = (this.btnEdit.Enabled == true ? false : true);
            this.btnSave.Enabled = (this.btnSave.Enabled == true ? false : true);
            this.txtPassword.Enabled = (this.txtPassword.Enabled == true ? false : true);
            this.txtPhone.Enabled = (this.txtPhone.Enabled == true ? false : true);
            this.txtUserName.Enabled = (this.txtUserName.Enabled == true ? false : true);
            this.dtpDOB.Enabled = (this.dtpDOB.Enabled == true ? false : true);
            this.btnEye.Enabled = (this.btnEye.Enabled == true ? false : true);
        }

        private void txtSearchProduct_MouseClick(object sender, MouseEventArgs e)
        {
            txtSearchProduct_search();
        }

        private void txtSearchProduct_Leave(object sender, EventArgs e)
        {
            txtSearchProduct_empty();
        }

        private void txtSearchProduct_empty()
        {
            if (this.txtSearchProduct.Text == "")
            {
                this.txtSearchProduct.Text = "Search";
                this.txtSearchProduct.ForeColor = Color.Gray;
            }
        }
        private void txtSearchProduct_search()
        {
            if (this.txtSearchProduct.Text == "Search")
            {
                this.txtSearchProduct.Clear();
                this.txtSearchProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(31)))), ((int)(((byte)(48)))));
            }
        }

        private void resetHome()
        {
            this.txtSearchProduct.Text = "";
            txtSearchProduct_empty();
            this.cmbCategory.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.pnlOrange.Focus();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.pnlOrange.Focus();
            this.Login.Show();
            this.Hide();

        }


       

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (this.cmbCategory.SelectedIndex == 0) this.PopulateGridView();
            else this.PopulateGridView("Select * from ProductInformation where Category = '" + this.cmbCategory.Text + "';");
        }

        private void txtSearchProduct_TextChanged(object sender, EventArgs e)
        {
            var sql = "Select * from ProductInformation where ProductName LIKE '"+this.txtSearchProduct.Text+ "%' or Category LIKE '" + this.txtSearchProduct.Text + "%' or Price LIKE '" + this.txtSearchProduct.Text + "%'";
            this.PopulateGridView(sql);
        }
        private void dgvProducts_DoubleClick(object sender, EventArgs e)
        {
            
            string str = this.dgvProducts.CurrentRow.Cells["ProductName"].Value.ToString();

            //MessageBox.Show(str);
            this.dgvCart.Rows.Add();
            this.dgvCart.Rows[(dgvCart.Rows.Count)-1].Cells[0].Value = str;
        }

        private void Employee_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Environment.Exit(1);
        }
    }
}
