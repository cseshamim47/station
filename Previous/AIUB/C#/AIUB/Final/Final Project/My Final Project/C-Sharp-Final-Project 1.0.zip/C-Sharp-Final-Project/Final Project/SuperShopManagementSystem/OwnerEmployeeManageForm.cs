﻿using SuperShopManegementSystem;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperShopManagementSystem
{
    public partial class OwnerEmployeeManageForm : Form
    {
        private DataAccess Da { get; set; }
        public OwnerEmployeeManageForm()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            //this.txtUserId.Text = this.AutoGenerateId();
        }
        private void PopulateGridView(string sql = "select * from UserInformation where Role = 'Employee';")
        {
            var ds = this.Da.ExecuteQuery(sql);
            this.dgvEmployeeView.AutoGenerateColumns = false;
            this.dgvEmployeeView.DataSource = ds.Tables[0];
            this.txtUserId.Text = this.AutoGenerateId();
        }


        #region Auto Generate Id
        private string AutoGenerateId()
        {
            string id = "E-";
            string sql = "select * from UserInformation where Role = 'Employee';";
            var ds = this.Da.ExecuteQueryTable(sql);
            int i = 1;
            if (ds.Rows.Count != 0)
            {
                i = Int32.Parse(ds.Rows[ds.Rows.Count - 1][0].ToString().Substring(2)) + 1;
                id += i.ToString("D3");
            }
            else
            {
                id += i.ToString("D3");
            }
            
            return id;
        }
        #endregion

        private void RefreshContent()
        {
            this.txtUserName.Text = "";
            this.txtSalary.Text = "";
            this.dtpJoiningDate.Text = "";
            this.dtpDateOfBirth.Text = "";
            this.txtAddress.Text = "";
            this.txtPhoneNumber.Clear();
            this.txtSearch.Clear();
        }

        private void btnShowInfo_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.RefreshContent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsValidToSaveData())
                {
                    MessageBox.Show("Invalid opration. Please fill up all the information");
                    return;
                }
                var query = "select * from UserInformation where UserId = '" + this.txtUserId.Text + "';";
                var ds = this.Da.ExecuteQuery(query);

                if (ds.Tables[0].Rows.Count == 1)
                {
                    //update
                    var sql = @"update UserInformation
                                set UserName = '" + this.txtUserName.Text + @"',
                                Salary = '" + this.txtSalary.Text + @"', 
                                JoiningDate = '" + this.dtpJoiningDate.Text + @"',
                                DateOfBirth = '" + this.dtpDateOfBirth.Text + @"',
                                Address = '" + this.txtAddress.Text + @"',
                                PhoneNumber = '" + this.txtPhoneNumber.Text + @"'
                                where UserId = '" + this.txtUserId.Text + "';";
                    int count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data updated successfully");
                    else
                        MessageBox.Show("Data upgradation failed");
                }
                else
                {
                    //insert
                    var sql = @"insert into UserInformation values('" + this.txtUserId.Text + "','" + this.txtUserName.Text + "','" + this.txtSalary.Text + " TK','" + this.dtpJoiningDate.Text + "','" + this.dtpDateOfBirth.Text + "','" + this.txtAddress.Text + "','" + this.txtPhoneNumber.Text + "','Employee');";
                    int count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data insertion successfull");
                    else
                        MessageBox.Show("Data insertion failed");
                }

                this.PopulateGridView();
                this.RefreshContent();
        }
        catch (Exception exc)
        {
            MessageBox.Show("An error has occured: " + exc.Message);
        }

}
    private bool IsValidToSaveData()
        {
            if (String.IsNullOrEmpty(this.txtUserId.Text) || String.IsNullOrEmpty(this.txtUserName.Text) ||
                String.IsNullOrEmpty(this.txtSalary.Text) || String.IsNullOrEmpty(this.txtAddress.Text) || String.IsNullOrWhiteSpace(this.txtPhoneNumber.Text))
            {
                return false;
            }
            else
                return true;
        }

        private void dgvEmployeeView_DoubleClick(object sender, EventArgs e)
        {
            this.txtUserId.Text = this.dgvEmployeeView.CurrentRow.Cells["UserId"].Value.ToString();
            this.txtUserName.Text = this.dgvEmployeeView.CurrentRow.Cells["UserName"].Value.ToString();
            this.txtSalary.Text = this.dgvEmployeeView.CurrentRow.Cells["Salary"].Value.ToString();
            this.dtpJoiningDate.Text = this.dgvEmployeeView.CurrentRow.Cells["JoiningDate"].Value.ToString();
            this.dtpDateOfBirth.Text = this.dgvEmployeeView.CurrentRow.Cells["DateOfBirth"].Value.ToString();
            this.txtAddress.Text = this.dgvEmployeeView.CurrentRow.Cells["Address"].Value.ToString();
            this.txtPhoneNumber.Text = this.dgvEmployeeView.CurrentRow.Cells["PhoneNumber"].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                var id = this.dgvEmployeeView.CurrentRow.Cells[0].Value.ToString();
                var name = this.dgvEmployeeView.CurrentRow.Cells[1].Value.ToString();

                var sql = "delete from UserInformation where UserId = '" + id + "';";
                int count = this.Da.ExecuteDMLQuery(sql);

                if (count == 1)
                    MessageBox.Show(name + " has been deleted successfully");
                else
                    MessageBox.Show("Data deletion failed");

                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = "select * from UserInformation where UserName like '%" + this.txtSearch.Text + "%' and Role = 'Employee';";// or Id like '"+this.txtMovieId.Text+"%';";
            this.PopulateGridView(sql);
        }

        private void OwnerEmployeeManageForm_Load(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }
    }
}
