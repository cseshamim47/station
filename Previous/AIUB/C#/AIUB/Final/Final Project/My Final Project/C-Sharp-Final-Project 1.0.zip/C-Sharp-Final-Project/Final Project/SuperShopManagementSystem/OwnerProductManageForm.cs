﻿using SuperShopManegementSystem;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperShopManagementSystem
{
    public partial class OwnerProductManageForm : Form
    {
        private DataAccess Da { get; set; }
        public OwnerProductManageForm()
        {
            InitializeComponent();
            this.Da = new DataAccess();

        }
        private void PopulateGridView(string sql = "select * from ProductInformation;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvProductView.AutoGenerateColumns = false;
            this.dgvProductView.DataSource = ds.Tables[0];
            this.txtProductId.Text = this.AutoGenerateId();
        }

        #region Auto Generate Id
        private string AutoGenerateId()
        {
            string id = "P-";
            string sql = "select * from ProductInformation;";
            var ds = this.Da.ExecuteQueryTable(sql);
            int i = 1;
            if (ds.Rows.Count != 0)
            {
                i = Int32.Parse(ds.Rows[ds.Rows.Count - 1][0].ToString().Substring(2)) + 1;
                id += i.ToString("D3");
            }
            else
            {
                id += i.ToString("D3");
            }

            return id;
        }
        #endregion

        private void btnShowInfo_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();

        }
        private void RefreshContent()
        {
            this.txtProductName.Clear();
            this.txtPrice.Clear();
            this.dtpExpiryDate.Text = "";
            this.dtpStockDate.Text = "";
            this.txtQuantity.Text = "";
            this.cmbCategory.SelectedIndex = -1;
            this.txtSearch.Clear();
            this.cmbSearchByCategory.SelectedIndex = -1;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.RefreshContent();
        }

        private bool IsValidToSaveData()
        {
            if (String.IsNullOrEmpty(this.txtProductId.Text) || String.IsNullOrEmpty(this.txtProductName.Text) ||
                String.IsNullOrEmpty(this.cmbCategory.Text) || String.IsNullOrEmpty(this.txtPrice.Text) || String.IsNullOrWhiteSpace(this.txtQuantity.Text))
            {
                return false;
            }
            else
                return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsValidToSaveData())
                {
                    MessageBox.Show("Invalid opration. Please fill up all the information");
                    return;
                }

                var query = "select * from ProductInformation where ProductId = '" + this.txtProductId.Text + "';";
                var ds = this.Da.ExecuteQuery(query);

                if (ds.Tables[0].Rows.Count == 1)
                {
                    //update
                    var sql = @"update ProductInformation
                                set ProductName = '" + this.txtProductName.Text + @"',
                                Category = '" + this.cmbCategory.Text + @"', 
                                Price = '" + this.txtPrice.Text + @"',
                                Quantity = " + this.txtQuantity.Text + @",
                                StockDate = '" + this.dtpStockDate.Text + @"',
                                ExpiryDate = '" + this.dtpExpiryDate.Text + @"'
                                where ProductId = '" + this.txtProductId.Text + "';";
                    int count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data updated successfully");
                    else
                        MessageBox.Show("Data upgradation failed");
                }
                else
                {
                    //insert
                    var sql = @"insert into ProductInformation values('" + this.txtProductId.Text + "','" + this.txtProductName.Text + "','" + this.cmbCategory.Text + "','" + this.txtPrice.Text + " TK'," + this.txtQuantity.Text + ",'" + this.dtpStockDate.Text + "','" + this.dtpExpiryDate.Text + "');";
                    int count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data insertion successfull");
                    else
                        MessageBox.Show("Data insertion failed");
                }

                this.PopulateGridView();
                this.RefreshContent();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
        }

        private void dgvProductView_DoubleClick(object sender, EventArgs e)
        {
            this.txtProductId.Text = this.dgvProductView.CurrentRow.Cells["ProductId"].Value.ToString();
            this.txtProductName.Text = this.dgvProductView.CurrentRow.Cells["ProductName"].Value.ToString();
            this.cmbCategory.Text = this.dgvProductView.CurrentRow.Cells["Category"].Value.ToString();
            this.txtPrice.Text = this.dgvProductView.CurrentRow.Cells["Price"].Value.ToString();
            this.txtQuantity.Text = this.dgvProductView.CurrentRow.Cells["Quantity"].Value.ToString();
            this.dtpStockDate.Text = this.dgvProductView.CurrentRow.Cells["StockDate"].Value.ToString();
            this.dtpExpiryDate.Text = this.dgvProductView.CurrentRow.Cells["ExpiryDate"].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                var id = this.dgvProductView.CurrentRow.Cells[0].Value.ToString();
                var name = this.dgvProductView.CurrentRow.Cells[1].Value.ToString();

                var sql = "delete from ProductInformation where ProductId = '" + id + "';";
                int count = this.Da.ExecuteDMLQuery(sql);

                if (count == 1)
                    MessageBox.Show(name + " has been deleted successfully");
                else
                    MessageBox.Show("Data deletion failed");

                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = "select * from ProductInformation where ProductName like '%" + this.txtSearch.Text + "%';";// or Id like '"+this.txtMovieId.Text+"%';";
            this.PopulateGridView(sql);
        }

        
        private void cmbSearchByCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (this.cmbSearchByCategory.SelectedIndex == 0) this.PopulateGridView();
            else this.PopulateGridView("Select * from ProductInformation where Category = '" + this.cmbSearchByCategory.Text + "';");
        }

        private void OwnerProductManageForm_Load(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }
    }
}
