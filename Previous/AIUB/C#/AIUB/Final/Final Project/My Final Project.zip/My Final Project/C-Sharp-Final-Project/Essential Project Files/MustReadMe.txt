csharp
#Random2022


Database Login Id = sa
Databae Login Pass = #random2022.

### Color Codes
Blue 
27,31,48
Brown
115,60,60
orange
176, 66, 35
Border Hover Color
180, 110, 110
Border Active Color
115,60,60



260,36 --- textbox

8 gap between blue orange shape

213, 553

OrderedMedicineName
OrderedQuantity
OrderedPerUnitPrice
OrderedPrice

1399, 800


# task remaining

Scroll button
3. all form connect
4. validation
5. Report - kobe ki sell hoise
7. total income - optional

change admin default id pass in admin class and employee class
#task done
1. login logout
2. cross button
6. profile show


trx id subtotal discount total seller   date 
	1	500q	10		  450	shamim  today

orange	

cartProductName
cartPrice
cartQuantity
cartTotal
cartProductId
cartTransactionId
cartSellerName

	
