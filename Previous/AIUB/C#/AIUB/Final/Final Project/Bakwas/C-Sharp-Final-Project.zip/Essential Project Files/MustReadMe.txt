csharp
#Random2022


Database Login Id = sa
Databae Login Pass = #random2022.

### Color Codes
Blue 
27,31,48
Brown
115,60,60
orange
176, 66, 35
Border Hover Color
180, 110, 110
Border Active Color
115,60,60


