﻿namespace CustomControls
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.iconButton7 = new FontAwesome.Sharp.IconButton();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.rjButton3 = new CustomControls.RJControls.RJButton();
            this.rjButton2 = new CustomControls.RJControls.RJButton();
            this.rjButton1 = new CustomControls.RJControls.RJButton();
            this.rjDropdownMenu1 = new CustomControls.RJControls.RJDropdownMenu(this.components);
            this.gergeargToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gergeragToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geargeargToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gergeargearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gergergeaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerageargearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gergeragToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gergeragToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.gergeargToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gergegtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gegeeaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gegeagearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gegeageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gegegeaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gegeageaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gegeagToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geageagearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gegeagToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gegeageargeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rjDropdownMenu2 = new CustomControls.RJControls.RJDropdownMenu(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.rjDropdownMenu3 = new CustomControls.RJControls.RJDropdownMenu(this.components);
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem38 = new System.Windows.Forms.ToolStripMenuItem();
            this.rjDropdownMenu4 = new CustomControls.RJControls.RJDropdownMenu(this.components);
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem46 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem52 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem53 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem54 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem55 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem56 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem57 = new System.Windows.Forms.ToolStripMenuItem();
            this.rjDropdownMenu5 = new CustomControls.RJControls.RJDropdownMenu(this.components);
            this.toolStripMenuItem58 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem59 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem60 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem61 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem62 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem63 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem64 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem65 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem66 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem67 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem68 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem69 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem70 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem71 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem72 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem73 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem74 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem75 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem76 = new System.Windows.Forms.ToolStripMenuItem();
            this.rjDropdownMenu6 = new CustomControls.RJControls.RJDropdownMenu(this.components);
            this.hhyrjhtyjToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtydjtdyjtdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjdyjtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrhdrhrtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrdhrdthrtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrhrdhrtdrthToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrdhrdthrToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrdhrdhrdtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrhrdhrthToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrtdhrdthrtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrtdhrdthToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrtdhrdhrtdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrdhrdhrtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hrtdhrdthrdtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtyjtjtjtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtyjtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjttyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtyjToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtyjToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtyjtToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtyjtyjToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jtyjtyjjtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rjDropdownMenu7 = new CustomControls.RJControls.RJDropdownMenu(this.components);
            this.toolStripMenuItem77 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem78 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem79 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem80 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem81 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem82 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem83 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem84 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem85 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem86 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem87 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem88 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem89 = new System.Windows.Forms.ToolStripMenuItem();
            this.fwefwaeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fwfwaefToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fwafwafwaeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fwaefwaefwaeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fwafwafwafwaeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fwefwaefwfeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem90 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem91 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem92 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem93 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem94 = new System.Windows.Forms.ToolStripMenuItem();
            this.fwefweaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fweafwaefToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fwefwafwaeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fweafwafToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem95 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem96 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem97 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem98 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem99 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem100 = new System.Windows.Forms.ToolStripMenuItem();
            this.rjTextBox1 = new CustomControls.RJControls.RJTextBox();
            this.rjButton4 = new CustomControls.RJControls.RJButton();
            this.rjButton5 = new CustomControls.RJControls.RJButton();
            this.rjDropdownMenu8 = new CustomControls.RJControls.RJDropdownMenu(this.components);
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.iconMenuItem1 = new FontAwesome.Sharp.IconMenuItem();
            this.asdfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asdfToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.rjDropdownMenu1.SuspendLayout();
            this.rjDropdownMenu2.SuspendLayout();
            this.rjDropdownMenu3.SuspendLayout();
            this.rjDropdownMenu4.SuspendLayout();
            this.rjDropdownMenu5.SuspendLayout();
            this.rjDropdownMenu6.SuspendLayout();
            this.rjDropdownMenu7.SuspendLayout();
            this.rjDropdownMenu8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1379, 62);
            this.panel1.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(399, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(578, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Custom Controls - C# WinForms";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(36)))));
            this.panel2.Controls.Add(this.iconButton7);
            this.panel2.Controls.Add(this.iconButton6);
            this.panel2.Controls.Add(this.iconButton5);
            this.panel2.Controls.Add(this.iconButton4);
            this.panel2.Controls.Add(this.iconButton3);
            this.panel2.Controls.Add(this.iconButton2);
            this.panel2.Controls.Add(this.iconButton1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 62);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(0, 62, 0, 0);
            this.panel2.Size = new System.Drawing.Size(293, 567);
            this.panel2.TabIndex = 26;
            // 
            // iconButton7
            // 
            this.iconButton7.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton7.FlatAppearance.BorderSize = 0;
            this.iconButton7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(52)))), ((int)(((byte)(183)))));
            this.iconButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton7.IconChar = FontAwesome.Sharp.IconChar.Instagram;
            this.iconButton7.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton7.IconSize = 25;
            this.iconButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton7.Location = new System.Drawing.Point(0, 434);
            this.iconButton7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.iconButton7.Name = "iconButton7";
            this.iconButton7.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.iconButton7.Size = new System.Drawing.Size(293, 62);
            this.iconButton7.TabIndex = 6;
            this.iconButton7.Text = "   iconButton7";
            this.iconButton7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton7.UseVisualStyleBackColor = true;
            // 
            // iconButton6
            // 
            this.iconButton6.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton6.FlatAppearance.BorderSize = 0;
            this.iconButton6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(52)))), ((int)(((byte)(183)))));
            this.iconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.ItunesNote;
            this.iconButton6.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 25;
            this.iconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton6.Location = new System.Drawing.Point(0, 372);
            this.iconButton6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.iconButton6.Size = new System.Drawing.Size(293, 62);
            this.iconButton6.TabIndex = 5;
            this.iconButton6.Text = "   iconButton6";
            this.iconButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton6.UseVisualStyleBackColor = true;
            // 
            // iconButton5
            // 
            this.iconButton5.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton5.FlatAppearance.BorderSize = 0;
            this.iconButton5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(52)))), ((int)(((byte)(183)))));
            this.iconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.Khanda;
            this.iconButton5.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 25;
            this.iconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton5.Location = new System.Drawing.Point(0, 310);
            this.iconButton5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.iconButton5.Size = new System.Drawing.Size(293, 62);
            this.iconButton5.TabIndex = 4;
            this.iconButton5.Text = "   iconButton5";
            this.iconButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton5.UseVisualStyleBackColor = true;
            // 
            // iconButton4
            // 
            this.iconButton4.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton4.FlatAppearance.BorderSize = 0;
            this.iconButton4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(52)))), ((int)(((byte)(183)))));
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.Key;
            this.iconButton4.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 25;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton4.Location = new System.Drawing.Point(0, 248);
            this.iconButton4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.iconButton4.Size = new System.Drawing.Size(293, 62);
            this.iconButton4.TabIndex = 3;
            this.iconButton4.Text = "   iconButton4";
            this.iconButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton4.UseVisualStyleBackColor = true;
            this.iconButton4.Click += new System.EventHandler(this.iconButton4_Click);
            // 
            // iconButton3
            // 
            this.iconButton3.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton3.FlatAppearance.BorderSize = 0;
            this.iconButton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(52)))), ((int)(((byte)(183)))));
            this.iconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.Js;
            this.iconButton3.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.IconSize = 25;
            this.iconButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton3.Location = new System.Drawing.Point(0, 186);
            this.iconButton3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.iconButton3.Size = new System.Drawing.Size(293, 62);
            this.iconButton3.TabIndex = 2;
            this.iconButton3.Text = "   iconButton3";
            this.iconButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton3.UseVisualStyleBackColor = true;
            this.iconButton3.Click += new System.EventHandler(this.iconButton3_Click);
            // 
            // iconButton2
            // 
            this.iconButton2.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton2.FlatAppearance.BorderSize = 0;
            this.iconButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(52)))), ((int)(((byte)(183)))));
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.JournalWhills;
            this.iconButton2.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 25;
            this.iconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.Location = new System.Drawing.Point(0, 124);
            this.iconButton2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.iconButton2.Size = new System.Drawing.Size(293, 62);
            this.iconButton2.TabIndex = 1;
            this.iconButton2.Text = "   iconButton2";
            this.iconButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton2.UseVisualStyleBackColor = true;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // iconButton1
            // 
            this.iconButton1.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconButton1.FlatAppearance.BorderSize = 0;
            this.iconButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(52)))), ((int)(((byte)(183)))));
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.FacebookMessenger;
            this.iconButton1.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(149)))), ((int)(((byte)(183)))));
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 25;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.Location = new System.Drawing.Point(0, 62);
            this.iconButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Padding = new System.Windows.Forms.Padding(13, 0, 0, 0);
            this.iconButton1.Size = new System.Drawing.Size(293, 62);
            this.iconButton1.TabIndex = 0;
            this.iconButton1.Text = "   iconButton1";
            this.iconButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton1.UseVisualStyleBackColor = true;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // rjButton3
            // 
            this.rjButton3.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton3.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton3.BorderRadius = 20;
            this.rjButton3.BorderSize = 0;
            this.rjButton3.FlatAppearance.BorderSize = 0;
            this.rjButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton3.ForeColor = System.Drawing.Color.White;
            this.rjButton3.Location = new System.Drawing.Point(355, 345);
            this.rjButton3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rjButton3.Name = "rjButton3";
            this.rjButton3.Size = new System.Drawing.Size(200, 49);
            this.rjButton3.TabIndex = 31;
            this.rjButton3.Text = "rjButton3";
            this.rjButton3.TextColor = System.Drawing.Color.White;
            this.rjButton3.UseVisualStyleBackColor = false;
            this.rjButton3.Click += new System.EventHandler(this.rjButton3_Click);
            // 
            // rjButton2
            // 
            this.rjButton2.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton2.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton2.BorderRadius = 20;
            this.rjButton2.BorderSize = 0;
            this.rjButton2.FlatAppearance.BorderSize = 0;
            this.rjButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton2.ForeColor = System.Drawing.Color.White;
            this.rjButton2.Location = new System.Drawing.Point(355, 246);
            this.rjButton2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rjButton2.Name = "rjButton2";
            this.rjButton2.Size = new System.Drawing.Size(200, 49);
            this.rjButton2.TabIndex = 30;
            this.rjButton2.Text = "rjButton2";
            this.rjButton2.TextColor = System.Drawing.Color.White;
            this.rjButton2.UseVisualStyleBackColor = false;
            this.rjButton2.Click += new System.EventHandler(this.rjButton2_Click);
            // 
            // rjButton1
            // 
            this.rjButton1.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton1.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton1.BorderRadius = 20;
            this.rjButton1.BorderSize = 0;
            this.rjButton1.FlatAppearance.BorderSize = 0;
            this.rjButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton1.ForeColor = System.Drawing.Color.White;
            this.rjButton1.Location = new System.Drawing.Point(355, 130);
            this.rjButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rjButton1.Name = "rjButton1";
            this.rjButton1.Size = new System.Drawing.Size(200, 49);
            this.rjButton1.TabIndex = 29;
            this.rjButton1.Text = "rjButton1";
            this.rjButton1.TextColor = System.Drawing.Color.White;
            this.rjButton1.UseVisualStyleBackColor = false;
            this.rjButton1.Click += new System.EventHandler(this.rjButton1_Click);
            // 
            // rjDropdownMenu1
            // 
            this.rjDropdownMenu1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjDropdownMenu1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.rjDropdownMenu1.IsMainMenu = false;
            this.rjDropdownMenu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gergeargToolStripMenuItem,
            this.gergeragToolStripMenuItem,
            this.gergegtToolStripMenuItem,
            this.gegeeaToolStripMenuItem,
            this.gegeageaToolStripMenuItem});
            this.rjDropdownMenu1.MenuItemHeight = 25;
            this.rjDropdownMenu1.MenuItemTextColor = System.Drawing.Color.DimGray;
            this.rjDropdownMenu1.Name = "rjDropdownMenu1";
            this.rjDropdownMenu1.PrimaryColor = System.Drawing.Color.MediumSlateBlue;
            this.rjDropdownMenu1.Size = new System.Drawing.Size(151, 124);
            // 
            // gergeargToolStripMenuItem
            // 
            this.gergeargToolStripMenuItem.Name = "gergeargToolStripMenuItem";
            this.gergeargToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
            this.gergeargToolStripMenuItem.Text = "gergearg";
            // 
            // gergeragToolStripMenuItem
            // 
            this.gergeragToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.geargeargToolStripMenuItem,
            this.gergeargearToolStripMenuItem,
            this.gergeragToolStripMenuItem2,
            this.gergeargToolStripMenuItem1});
            this.gergeragToolStripMenuItem.Name = "gergeragToolStripMenuItem";
            this.gergeragToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
            this.gergeragToolStripMenuItem.Text = "gergerag";
            // 
            // geargeargToolStripMenuItem
            // 
            this.geargeargToolStripMenuItem.Name = "geargeargToolStripMenuItem";
            this.geargeargToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.geargeargToolStripMenuItem.Text = "geargearg";
            // 
            // gergeargearToolStripMenuItem
            // 
            this.gergeargearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gergergeaToolStripMenuItem,
            this.gerageargearToolStripMenuItem,
            this.gergeragToolStripMenuItem1});
            this.gergeargearToolStripMenuItem.Name = "gergeargearToolStripMenuItem";
            this.gergeargearToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.gergeargearToolStripMenuItem.Text = "gergeargear";
            // 
            // gergergeaToolStripMenuItem
            // 
            this.gergergeaToolStripMenuItem.Name = "gergergeaToolStripMenuItem";
            this.gergergeaToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.gergergeaToolStripMenuItem.Text = "gergergea";
            // 
            // gerageargearToolStripMenuItem
            // 
            this.gerageargearToolStripMenuItem.Name = "gerageargearToolStripMenuItem";
            this.gerageargearToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.gerageargearToolStripMenuItem.Text = "gerageargear";
            // 
            // gergeragToolStripMenuItem1
            // 
            this.gergeragToolStripMenuItem1.Name = "gergeragToolStripMenuItem1";
            this.gergeragToolStripMenuItem1.Size = new System.Drawing.Size(191, 26);
            this.gergeragToolStripMenuItem1.Text = "gergerag";
            // 
            // gergeragToolStripMenuItem2
            // 
            this.gergeragToolStripMenuItem2.Name = "gergeragToolStripMenuItem2";
            this.gergeragToolStripMenuItem2.Size = new System.Drawing.Size(182, 26);
            this.gergeragToolStripMenuItem2.Text = "gergerag";
            // 
            // gergeargToolStripMenuItem1
            // 
            this.gergeargToolStripMenuItem1.Name = "gergeargToolStripMenuItem1";
            this.gergeargToolStripMenuItem1.Size = new System.Drawing.Size(182, 26);
            this.gergeargToolStripMenuItem1.Text = "gergearg";
            // 
            // gergegtToolStripMenuItem
            // 
            this.gergegtToolStripMenuItem.Name = "gergegtToolStripMenuItem";
            this.gergegtToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
            this.gergegtToolStripMenuItem.Text = "gergegt";
            // 
            // gegeeaToolStripMenuItem
            // 
            this.gegeeaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gegeagearToolStripMenuItem,
            this.gegeageToolStripMenuItem,
            this.gegegeaToolStripMenuItem});
            this.gegeeaToolStripMenuItem.Name = "gegeeaToolStripMenuItem";
            this.gegeeaToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
            this.gegeeaToolStripMenuItem.Text = "gegeea";
            // 
            // gegeagearToolStripMenuItem
            // 
            this.gegeagearToolStripMenuItem.Name = "gegeagearToolStripMenuItem";
            this.gegeagearToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.gegeagearToolStripMenuItem.Text = "gegeagear";
            // 
            // gegeageToolStripMenuItem
            // 
            this.gegeageToolStripMenuItem.Name = "gegeageToolStripMenuItem";
            this.gegeageToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.gegeageToolStripMenuItem.Text = "gegeage";
            // 
            // gegegeaToolStripMenuItem
            // 
            this.gegegeaToolStripMenuItem.Name = "gegegeaToolStripMenuItem";
            this.gegegeaToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.gegegeaToolStripMenuItem.Text = "gegegea";
            // 
            // gegeageaToolStripMenuItem
            // 
            this.gegeageaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gegeagToolStripMenuItem,
            this.geageagearToolStripMenuItem});
            this.gegeageaToolStripMenuItem.Name = "gegeageaToolStripMenuItem";
            this.gegeageaToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
            this.gegeageaToolStripMenuItem.Text = "gegeagea";
            // 
            // gegeagToolStripMenuItem
            // 
            this.gegeagToolStripMenuItem.Name = "gegeagToolStripMenuItem";
            this.gegeagToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.gegeagToolStripMenuItem.Text = "gegeag";
            // 
            // geageagearToolStripMenuItem
            // 
            this.geageagearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gegeagToolStripMenuItem1,
            this.gegeageargeToolStripMenuItem});
            this.geageagearToolStripMenuItem.Name = "geageagearToolStripMenuItem";
            this.geageagearToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.geageagearToolStripMenuItem.Text = "geageagear";
            // 
            // gegeagToolStripMenuItem1
            // 
            this.gegeagToolStripMenuItem1.Name = "gegeagToolStripMenuItem1";
            this.gegeagToolStripMenuItem1.Size = new System.Drawing.Size(188, 26);
            this.gegeagToolStripMenuItem1.Text = "gegeag";
            // 
            // gegeageargeToolStripMenuItem
            // 
            this.gegeageargeToolStripMenuItem.Name = "gegeageargeToolStripMenuItem";
            this.gegeageargeToolStripMenuItem.Size = new System.Drawing.Size(188, 26);
            this.gegeageargeToolStripMenuItem.Text = "gegeagearge";
            // 
            // rjDropdownMenu2
            // 
            this.rjDropdownMenu2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjDropdownMenu2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.rjDropdownMenu2.IsMainMenu = false;
            this.rjDropdownMenu2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripMenuItem15});
            this.rjDropdownMenu2.MenuItemHeight = 25;
            this.rjDropdownMenu2.MenuItemTextColor = System.Drawing.Color.DimGray;
            this.rjDropdownMenu2.Name = "rjDropdownMenu1";
            this.rjDropdownMenu2.PrimaryColor = System.Drawing.Color.MediumSlateBlue;
            this.rjDropdownMenu2.Size = new System.Drawing.Size(151, 124);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem1.Text = "gergearg";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem2.Text = "gergerag";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem3.Text = "geargearg";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem4.Text = "gergeargear";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem5.Text = "gergergea";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem6.Text = "gerageargear";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem7.Text = "gergerag";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem8.Text = "gergerag";
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem9.Text = "gergearg";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem10.Text = "gergegt";
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem11.Text = "gegeea";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem12.Text = "gegeagear";
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem13.Text = "gegeage";
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem14.Text = "gegegea";
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem16,
            this.toolStripMenuItem17});
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem15.Text = "gegeagea";
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem16.Text = "gegeag";
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem18,
            this.toolStripMenuItem19});
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem17.Text = "geageagear";
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem18.Text = "gegeag";
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem19.Text = "gegeagearge";
            // 
            // rjDropdownMenu3
            // 
            this.rjDropdownMenu3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjDropdownMenu3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.rjDropdownMenu3.IsMainMenu = false;
            this.rjDropdownMenu3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem20,
            this.toolStripMenuItem21,
            this.toolStripMenuItem29,
            this.toolStripMenuItem30,
            this.toolStripMenuItem34});
            this.rjDropdownMenu3.MenuItemHeight = 25;
            this.rjDropdownMenu3.MenuItemTextColor = System.Drawing.Color.DimGray;
            this.rjDropdownMenu3.Name = "rjDropdownMenu1";
            this.rjDropdownMenu3.PrimaryColor = System.Drawing.Color.MediumSlateBlue;
            this.rjDropdownMenu3.Size = new System.Drawing.Size(151, 124);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem20.Text = "gergearg";
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem22,
            this.toolStripMenuItem23,
            this.toolStripMenuItem27,
            this.toolStripMenuItem28});
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem21.Text = "gergerag";
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem22.Text = "geargearg";
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem24,
            this.toolStripMenuItem25,
            this.toolStripMenuItem26});
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem23.Text = "gergeargear";
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem24.Text = "gergergea";
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem25.Text = "gerageargear";
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem26.Text = "gergerag";
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem27.Text = "gergerag";
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem28.Text = "gergearg";
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem29.Text = "gergegt";
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem31,
            this.toolStripMenuItem32,
            this.toolStripMenuItem33});
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem30.Text = "gegeea";
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem31.Text = "gegeagear";
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem32.Text = "gegeage";
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem33.Text = "gegegea";
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem35,
            this.toolStripMenuItem36});
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem34.Text = "gegeagea";
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem35.Text = "gegeag";
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem37,
            this.toolStripMenuItem38});
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem36.Text = "geageagear";
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem37.Text = "gegeag";
            // 
            // toolStripMenuItem38
            // 
            this.toolStripMenuItem38.Name = "toolStripMenuItem38";
            this.toolStripMenuItem38.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem38.Text = "gegeagearge";
            // 
            // rjDropdownMenu4
            // 
            this.rjDropdownMenu4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjDropdownMenu4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.rjDropdownMenu4.IsMainMenu = false;
            this.rjDropdownMenu4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem39,
            this.toolStripMenuItem40,
            this.toolStripMenuItem48,
            this.toolStripMenuItem49,
            this.toolStripMenuItem53});
            this.rjDropdownMenu4.MenuItemHeight = 25;
            this.rjDropdownMenu4.MenuItemTextColor = System.Drawing.Color.DimGray;
            this.rjDropdownMenu4.Name = "rjDropdownMenu1";
            this.rjDropdownMenu4.PrimaryColor = System.Drawing.Color.MediumSlateBlue;
            this.rjDropdownMenu4.Size = new System.Drawing.Size(151, 124);
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem39.Text = "gergearg";
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem41,
            this.toolStripMenuItem42,
            this.toolStripMenuItem46,
            this.toolStripMenuItem47});
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem40.Text = "gergerag";
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem41.Text = "geargearg";
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem43,
            this.toolStripMenuItem44,
            this.toolStripMenuItem45});
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem42.Text = "gergeargear";
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem43.Text = "gergergea";
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem44.Text = "gerageargear";
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem45.Text = "gergerag";
            // 
            // toolStripMenuItem46
            // 
            this.toolStripMenuItem46.Name = "toolStripMenuItem46";
            this.toolStripMenuItem46.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem46.Text = "gergerag";
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem47.Text = "gergearg";
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem48.Text = "gergegt";
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem50,
            this.toolStripMenuItem51,
            this.toolStripMenuItem52});
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem49.Text = "gegeea";
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem50.Text = "gegeagear";
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem51.Text = "gegeage";
            // 
            // toolStripMenuItem52
            // 
            this.toolStripMenuItem52.Name = "toolStripMenuItem52";
            this.toolStripMenuItem52.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem52.Text = "gegegea";
            // 
            // toolStripMenuItem53
            // 
            this.toolStripMenuItem53.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem54,
            this.toolStripMenuItem55});
            this.toolStripMenuItem53.Name = "toolStripMenuItem53";
            this.toolStripMenuItem53.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem53.Text = "gegeagea";
            // 
            // toolStripMenuItem54
            // 
            this.toolStripMenuItem54.Name = "toolStripMenuItem54";
            this.toolStripMenuItem54.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem54.Text = "gegeag";
            // 
            // toolStripMenuItem55
            // 
            this.toolStripMenuItem55.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem56,
            this.toolStripMenuItem57});
            this.toolStripMenuItem55.Name = "toolStripMenuItem55";
            this.toolStripMenuItem55.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem55.Text = "geageagear";
            // 
            // toolStripMenuItem56
            // 
            this.toolStripMenuItem56.Name = "toolStripMenuItem56";
            this.toolStripMenuItem56.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem56.Text = "gegeag";
            // 
            // toolStripMenuItem57
            // 
            this.toolStripMenuItem57.Name = "toolStripMenuItem57";
            this.toolStripMenuItem57.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem57.Text = "gegeagearge";
            // 
            // rjDropdownMenu5
            // 
            this.rjDropdownMenu5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjDropdownMenu5.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.rjDropdownMenu5.IsMainMenu = false;
            this.rjDropdownMenu5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem58,
            this.toolStripMenuItem59,
            this.toolStripMenuItem67,
            this.toolStripMenuItem68,
            this.toolStripMenuItem72});
            this.rjDropdownMenu5.MenuItemHeight = 25;
            this.rjDropdownMenu5.MenuItemTextColor = System.Drawing.Color.DimGray;
            this.rjDropdownMenu5.Name = "rjDropdownMenu1";
            this.rjDropdownMenu5.PrimaryColor = System.Drawing.Color.MediumSlateBlue;
            this.rjDropdownMenu5.Size = new System.Drawing.Size(151, 124);
            // 
            // toolStripMenuItem58
            // 
            this.toolStripMenuItem58.Name = "toolStripMenuItem58";
            this.toolStripMenuItem58.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem58.Text = "gergearg";
            // 
            // toolStripMenuItem59
            // 
            this.toolStripMenuItem59.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem60,
            this.toolStripMenuItem61,
            this.toolStripMenuItem65,
            this.toolStripMenuItem66});
            this.toolStripMenuItem59.Name = "toolStripMenuItem59";
            this.toolStripMenuItem59.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem59.Text = "gergerag";
            // 
            // toolStripMenuItem60
            // 
            this.toolStripMenuItem60.Name = "toolStripMenuItem60";
            this.toolStripMenuItem60.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem60.Text = "geargearg";
            // 
            // toolStripMenuItem61
            // 
            this.toolStripMenuItem61.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem62,
            this.toolStripMenuItem63,
            this.toolStripMenuItem64});
            this.toolStripMenuItem61.Name = "toolStripMenuItem61";
            this.toolStripMenuItem61.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem61.Text = "gergeargear";
            // 
            // toolStripMenuItem62
            // 
            this.toolStripMenuItem62.Name = "toolStripMenuItem62";
            this.toolStripMenuItem62.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem62.Text = "gergergea";
            // 
            // toolStripMenuItem63
            // 
            this.toolStripMenuItem63.Name = "toolStripMenuItem63";
            this.toolStripMenuItem63.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem63.Text = "gerageargear";
            // 
            // toolStripMenuItem64
            // 
            this.toolStripMenuItem64.Name = "toolStripMenuItem64";
            this.toolStripMenuItem64.Size = new System.Drawing.Size(191, 26);
            this.toolStripMenuItem64.Text = "gergerag";
            // 
            // toolStripMenuItem65
            // 
            this.toolStripMenuItem65.Name = "toolStripMenuItem65";
            this.toolStripMenuItem65.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem65.Text = "gergerag";
            // 
            // toolStripMenuItem66
            // 
            this.toolStripMenuItem66.Name = "toolStripMenuItem66";
            this.toolStripMenuItem66.Size = new System.Drawing.Size(182, 26);
            this.toolStripMenuItem66.Text = "gergearg";
            // 
            // toolStripMenuItem67
            // 
            this.toolStripMenuItem67.Name = "toolStripMenuItem67";
            this.toolStripMenuItem67.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem67.Text = "gergegt";
            // 
            // toolStripMenuItem68
            // 
            this.toolStripMenuItem68.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem69,
            this.toolStripMenuItem70,
            this.toolStripMenuItem71});
            this.toolStripMenuItem68.Name = "toolStripMenuItem68";
            this.toolStripMenuItem68.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem68.Text = "gegeea";
            // 
            // toolStripMenuItem69
            // 
            this.toolStripMenuItem69.Name = "toolStripMenuItem69";
            this.toolStripMenuItem69.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem69.Text = "gegeagear";
            // 
            // toolStripMenuItem70
            // 
            this.toolStripMenuItem70.Name = "toolStripMenuItem70";
            this.toolStripMenuItem70.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem70.Text = "gegeage";
            // 
            // toolStripMenuItem71
            // 
            this.toolStripMenuItem71.Name = "toolStripMenuItem71";
            this.toolStripMenuItem71.Size = new System.Drawing.Size(170, 26);
            this.toolStripMenuItem71.Text = "gegegea";
            // 
            // toolStripMenuItem72
            // 
            this.toolStripMenuItem72.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem73,
            this.toolStripMenuItem74});
            this.toolStripMenuItem72.Name = "toolStripMenuItem72";
            this.toolStripMenuItem72.Size = new System.Drawing.Size(150, 24);
            this.toolStripMenuItem72.Text = "gegeagea";
            // 
            // toolStripMenuItem73
            // 
            this.toolStripMenuItem73.Name = "toolStripMenuItem73";
            this.toolStripMenuItem73.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem73.Text = "gegeag";
            // 
            // toolStripMenuItem74
            // 
            this.toolStripMenuItem74.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem75,
            this.toolStripMenuItem76});
            this.toolStripMenuItem74.Name = "toolStripMenuItem74";
            this.toolStripMenuItem74.Size = new System.Drawing.Size(179, 26);
            this.toolStripMenuItem74.Text = "geageagear";
            // 
            // toolStripMenuItem75
            // 
            this.toolStripMenuItem75.Name = "toolStripMenuItem75";
            this.toolStripMenuItem75.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem75.Text = "gegeag";
            // 
            // toolStripMenuItem76
            // 
            this.toolStripMenuItem76.Name = "toolStripMenuItem76";
            this.toolStripMenuItem76.Size = new System.Drawing.Size(188, 26);
            this.toolStripMenuItem76.Text = "gegeagearge";
            // 
            // rjDropdownMenu6
            // 
            this.rjDropdownMenu6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjDropdownMenu6.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.rjDropdownMenu6.IsMainMenu = false;
            this.rjDropdownMenu6.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hhyrjhtyjToolStripMenuItem,
            this.jtydjtdyjtdToolStripMenuItem,
            this.jtyjdyjtToolStripMenuItem,
            this.hrtdhrdthrtToolStripMenuItem,
            this.hrtdhrdthrdtToolStripMenuItem,
            this.jtyjtyjtjtjtToolStripMenuItem});
            this.rjDropdownMenu6.MenuItemHeight = 25;
            this.rjDropdownMenu6.MenuItemTextColor = System.Drawing.Color.DimGray;
            this.rjDropdownMenu6.Name = "rjDropdownMenu6";
            this.rjDropdownMenu6.PrimaryColor = System.Drawing.Color.MediumSlateBlue;
            this.rjDropdownMenu6.Size = new System.Drawing.Size(166, 148);
            // 
            // hhyrjhtyjToolStripMenuItem
            // 
            this.hhyrjhtyjToolStripMenuItem.Name = "hhyrjhtyjToolStripMenuItem";
            this.hhyrjhtyjToolStripMenuItem.Size = new System.Drawing.Size(165, 24);
            this.hhyrjhtyjToolStripMenuItem.Text = "hhyrjhtyj";
            // 
            // jtydjtdyjtdToolStripMenuItem
            // 
            this.jtydjtdyjtdToolStripMenuItem.Name = "jtydjtdyjtdToolStripMenuItem";
            this.jtydjtdyjtdToolStripMenuItem.Size = new System.Drawing.Size(165, 24);
            this.jtydjtdyjtdToolStripMenuItem.Text = "jtydjtdyjtd";
            // 
            // jtyjdyjtToolStripMenuItem
            // 
            this.jtyjdyjtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jtyjtdToolStripMenuItem,
            this.hrhdrhrtToolStripMenuItem,
            this.hrdhrdthrtToolStripMenuItem,
            this.hrhrdhrthToolStripMenuItem});
            this.jtyjdyjtToolStripMenuItem.Name = "jtyjdyjtToolStripMenuItem";
            this.jtyjdyjtToolStripMenuItem.Size = new System.Drawing.Size(165, 24);
            this.jtyjdyjtToolStripMenuItem.Text = "jtyjdyjt";
            // 
            // jtyjtdToolStripMenuItem
            // 
            this.jtyjtdToolStripMenuItem.Name = "jtyjtdToolStripMenuItem";
            this.jtyjtdToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.jtyjtdToolStripMenuItem.Text = "jtyjtd";
            // 
            // hrhdrhrtToolStripMenuItem
            // 
            this.hrhdrhrtToolStripMenuItem.Name = "hrhdrhrtToolStripMenuItem";
            this.hrhdrhrtToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.hrhdrhrtToolStripMenuItem.Text = "hrhdrhrt";
            // 
            // hrdhrdthrtToolStripMenuItem
            // 
            this.hrdhrdthrtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hrhrdhrtdrthToolStripMenuItem,
            this.hrdhrdthrToolStripMenuItem,
            this.hrdhrdhrdtToolStripMenuItem});
            this.hrdhrdthrtToolStripMenuItem.Name = "hrdhrdthrtToolStripMenuItem";
            this.hrdhrdthrtToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.hrdhrdthrtToolStripMenuItem.Text = "hrdhrdthrt";
            // 
            // hrhrdhrtdrthToolStripMenuItem
            // 
            this.hrhrdhrtdrthToolStripMenuItem.Name = "hrhrdhrtdrthToolStripMenuItem";
            this.hrhrdhrtdrthToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.hrhrdhrtdrthToolStripMenuItem.Text = "hrhrdhrtdrth";
            // 
            // hrdhrdthrToolStripMenuItem
            // 
            this.hrdhrdthrToolStripMenuItem.Name = "hrdhrdthrToolStripMenuItem";
            this.hrdhrdthrToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.hrdhrdthrToolStripMenuItem.Text = "hrdhrdthr";
            // 
            // hrdhrdhrdtToolStripMenuItem
            // 
            this.hrdhrdhrdtToolStripMenuItem.Name = "hrdhrdhrdtToolStripMenuItem";
            this.hrdhrdhrdtToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.hrdhrdhrdtToolStripMenuItem.Text = "hrdhrdhrdt";
            // 
            // hrhrdhrthToolStripMenuItem
            // 
            this.hrhrdhrthToolStripMenuItem.Name = "hrhrdhrthToolStripMenuItem";
            this.hrhrdhrthToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.hrhrdhrthToolStripMenuItem.Text = "hrhrdhrth";
            // 
            // hrtdhrdthrtToolStripMenuItem
            // 
            this.hrtdhrdthrtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hrtdhrdthToolStripMenuItem,
            this.hrtdhrdhrtdToolStripMenuItem,
            this.hrdhrdhrtToolStripMenuItem});
            this.hrtdhrdthrtToolStripMenuItem.Name = "hrtdhrdthrtToolStripMenuItem";
            this.hrtdhrdthrtToolStripMenuItem.Size = new System.Drawing.Size(165, 24);
            this.hrtdhrdthrtToolStripMenuItem.Text = "hrtdhrdthrt";
            // 
            // hrtdhrdthToolStripMenuItem
            // 
            this.hrtdhrdthToolStripMenuItem.Name = "hrtdhrdthToolStripMenuItem";
            this.hrtdhrdthToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.hrtdhrdthToolStripMenuItem.Text = "hrtdhrdth";
            // 
            // hrtdhrdhrtdToolStripMenuItem
            // 
            this.hrtdhrdhrtdToolStripMenuItem.Name = "hrtdhrdhrtdToolStripMenuItem";
            this.hrtdhrdhrtdToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.hrtdhrdhrtdToolStripMenuItem.Text = "hrtdhrdhrtd";
            // 
            // hrdhrdhrtToolStripMenuItem
            // 
            this.hrdhrdhrtToolStripMenuItem.Name = "hrdhrdhrtToolStripMenuItem";
            this.hrdhrdhrtToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.hrdhrdhrtToolStripMenuItem.Text = "hrdhrdhrt";
            // 
            // hrtdhrdthrdtToolStripMenuItem
            // 
            this.hrtdhrdthrdtToolStripMenuItem.Name = "hrtdhrdthrdtToolStripMenuItem";
            this.hrtdhrdthrdtToolStripMenuItem.Size = new System.Drawing.Size(165, 24);
            this.hrtdhrdthrdtToolStripMenuItem.Text = "hrtdhrdthrdt";
            // 
            // jtyjtyjtjtjtToolStripMenuItem
            // 
            this.jtyjtyjtjtjtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jtyjtyjtToolStripMenuItem,
            this.jtyjtToolStripMenuItem,
            this.jtyjttyToolStripMenuItem});
            this.jtyjtyjtjtjtToolStripMenuItem.Name = "jtyjtyjtjtjtToolStripMenuItem";
            this.jtyjtyjtjtjtToolStripMenuItem.Size = new System.Drawing.Size(165, 24);
            this.jtyjtyjtjtjtToolStripMenuItem.Text = "jtyjtyjtjtjt";
            // 
            // jtyjtyjtToolStripMenuItem
            // 
            this.jtyjtyjtToolStripMenuItem.Name = "jtyjtyjtToolStripMenuItem";
            this.jtyjtyjtToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
            this.jtyjtyjtToolStripMenuItem.Text = "jtyjtyjt";
            // 
            // jtyjtToolStripMenuItem
            // 
            this.jtyjtToolStripMenuItem.Name = "jtyjtToolStripMenuItem";
            this.jtyjtToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
            this.jtyjtToolStripMenuItem.Text = "jtyjt";
            // 
            // jtyjttyToolStripMenuItem
            // 
            this.jtyjttyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jtyjtyjToolStripMenuItem,
            this.jtyjtyjToolStripMenuItem1});
            this.jtyjttyToolStripMenuItem.Name = "jtyjttyToolStripMenuItem";
            this.jtyjttyToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
            this.jtyjttyToolStripMenuItem.Text = "jtyjtty";
            // 
            // jtyjtyjToolStripMenuItem
            // 
            this.jtyjtyjToolStripMenuItem.Name = "jtyjtyjToolStripMenuItem";
            this.jtyjtyjToolStripMenuItem.Size = new System.Drawing.Size(130, 26);
            this.jtyjtyjToolStripMenuItem.Text = "jtyjtyj";
            // 
            // jtyjtyjToolStripMenuItem1
            // 
            this.jtyjtyjToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jtyjtyjtToolStripMenuItem1,
            this.jtyjtyjtyjToolStripMenuItem,
            this.jtyjtyjjtToolStripMenuItem});
            this.jtyjtyjToolStripMenuItem1.Name = "jtyjtyjToolStripMenuItem1";
            this.jtyjtyjToolStripMenuItem1.Size = new System.Drawing.Size(130, 26);
            this.jtyjtyjToolStripMenuItem1.Text = "jtyjtyj";
            // 
            // jtyjtyjtToolStripMenuItem1
            // 
            this.jtyjtyjtToolStripMenuItem1.Name = "jtyjtyjtToolStripMenuItem1";
            this.jtyjtyjtToolStripMenuItem1.Size = new System.Drawing.Size(147, 26);
            this.jtyjtyjtToolStripMenuItem1.Text = "jtyjtyjt";
            // 
            // jtyjtyjtyjToolStripMenuItem
            // 
            this.jtyjtyjtyjToolStripMenuItem.Name = "jtyjtyjtyjToolStripMenuItem";
            this.jtyjtyjtyjToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.jtyjtyjtyjToolStripMenuItem.Text = "jtyjtyjtyj";
            // 
            // jtyjtyjjtToolStripMenuItem
            // 
            this.jtyjtyjjtToolStripMenuItem.Name = "jtyjtyjjtToolStripMenuItem";
            this.jtyjtyjjtToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.jtyjtyjjtToolStripMenuItem.Text = "jtyjtyjjt";
            // 
            // rjDropdownMenu7
            // 
            this.rjDropdownMenu7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjDropdownMenu7.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.rjDropdownMenu7.IsMainMenu = false;
            this.rjDropdownMenu7.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem77,
            this.toolStripMenuItem78,
            this.toolStripMenuItem79,
            this.toolStripMenuItem87,
            this.toolStripMenuItem91,
            this.toolStripMenuItem92});
            this.rjDropdownMenu7.MenuItemHeight = 25;
            this.rjDropdownMenu7.MenuItemTextColor = System.Drawing.Color.DimGray;
            this.rjDropdownMenu7.Name = "rjDropdownMenu6";
            this.rjDropdownMenu7.PrimaryColor = System.Drawing.Color.MediumSlateBlue;
            this.rjDropdownMenu7.Size = new System.Drawing.Size(166, 148);
            // 
            // toolStripMenuItem77
            // 
            this.toolStripMenuItem77.Name = "toolStripMenuItem77";
            this.toolStripMenuItem77.Size = new System.Drawing.Size(165, 24);
            this.toolStripMenuItem77.Text = "hhyrjhtyj";
            // 
            // toolStripMenuItem78
            // 
            this.toolStripMenuItem78.Name = "toolStripMenuItem78";
            this.toolStripMenuItem78.Size = new System.Drawing.Size(165, 24);
            this.toolStripMenuItem78.Text = "jtydjtdyjtd";
            // 
            // toolStripMenuItem79
            // 
            this.toolStripMenuItem79.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem80,
            this.toolStripMenuItem81,
            this.toolStripMenuItem82,
            this.toolStripMenuItem86});
            this.toolStripMenuItem79.Name = "toolStripMenuItem79";
            this.toolStripMenuItem79.Size = new System.Drawing.Size(165, 24);
            this.toolStripMenuItem79.Text = "jtyjdyjt";
            // 
            // toolStripMenuItem80
            // 
            this.toolStripMenuItem80.Name = "toolStripMenuItem80";
            this.toolStripMenuItem80.Size = new System.Drawing.Size(165, 26);
            this.toolStripMenuItem80.Text = "jtyjtd";
            // 
            // toolStripMenuItem81
            // 
            this.toolStripMenuItem81.Name = "toolStripMenuItem81";
            this.toolStripMenuItem81.Size = new System.Drawing.Size(165, 26);
            this.toolStripMenuItem81.Text = "hrhdrhrt";
            // 
            // toolStripMenuItem82
            // 
            this.toolStripMenuItem82.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem83,
            this.toolStripMenuItem84,
            this.toolStripMenuItem85});
            this.toolStripMenuItem82.Name = "toolStripMenuItem82";
            this.toolStripMenuItem82.Size = new System.Drawing.Size(165, 26);
            this.toolStripMenuItem82.Text = "hrdhrdthrt";
            // 
            // toolStripMenuItem83
            // 
            this.toolStripMenuItem83.Name = "toolStripMenuItem83";
            this.toolStripMenuItem83.Size = new System.Drawing.Size(180, 26);
            this.toolStripMenuItem83.Text = "hrhrdhrtdrth";
            // 
            // toolStripMenuItem84
            // 
            this.toolStripMenuItem84.Name = "toolStripMenuItem84";
            this.toolStripMenuItem84.Size = new System.Drawing.Size(180, 26);
            this.toolStripMenuItem84.Text = "hrdhrdthr";
            // 
            // toolStripMenuItem85
            // 
            this.toolStripMenuItem85.Name = "toolStripMenuItem85";
            this.toolStripMenuItem85.Size = new System.Drawing.Size(180, 26);
            this.toolStripMenuItem85.Text = "hrdhrdhrdt";
            // 
            // toolStripMenuItem86
            // 
            this.toolStripMenuItem86.Name = "toolStripMenuItem86";
            this.toolStripMenuItem86.Size = new System.Drawing.Size(165, 26);
            this.toolStripMenuItem86.Text = "hrhrdhrth";
            // 
            // toolStripMenuItem87
            // 
            this.toolStripMenuItem87.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem88,
            this.toolStripMenuItem89,
            this.toolStripMenuItem90});
            this.toolStripMenuItem87.Name = "toolStripMenuItem87";
            this.toolStripMenuItem87.Size = new System.Drawing.Size(165, 24);
            this.toolStripMenuItem87.Text = "hrtdhrdthrt";
            // 
            // toolStripMenuItem88
            // 
            this.toolStripMenuItem88.Name = "toolStripMenuItem88";
            this.toolStripMenuItem88.Size = new System.Drawing.Size(174, 26);
            this.toolStripMenuItem88.Text = "hrtdhrdth";
            // 
            // toolStripMenuItem89
            // 
            this.toolStripMenuItem89.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fwefwaeToolStripMenuItem,
            this.fwfwaefToolStripMenuItem,
            this.fwafwafwaeToolStripMenuItem});
            this.toolStripMenuItem89.Name = "toolStripMenuItem89";
            this.toolStripMenuItem89.Size = new System.Drawing.Size(174, 26);
            this.toolStripMenuItem89.Text = "hrtdhrdhrtd";
            // 
            // fwefwaeToolStripMenuItem
            // 
            this.fwefwaeToolStripMenuItem.Name = "fwefwaeToolStripMenuItem";
            this.fwefwaeToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fwefwaeToolStripMenuItem.Text = "fwefwae";
            // 
            // fwfwaefToolStripMenuItem
            // 
            this.fwfwaefToolStripMenuItem.Name = "fwfwaefToolStripMenuItem";
            this.fwfwaefToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fwfwaefToolStripMenuItem.Text = "fwfwaef";
            // 
            // fwafwafwaeToolStripMenuItem
            // 
            this.fwafwafwaeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fwaefwaefwaeToolStripMenuItem,
            this.fwafwafwafwaeToolStripMenuItem,
            this.fwefwaefwfeToolStripMenuItem});
            this.fwafwafwaeToolStripMenuItem.Name = "fwafwafwaeToolStripMenuItem";
            this.fwafwafwaeToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fwafwafwaeToolStripMenuItem.Text = "fwafwafwae";
            // 
            // fwaefwaefwaeToolStripMenuItem
            // 
            this.fwaefwaefwaeToolStripMenuItem.Name = "fwaefwaefwaeToolStripMenuItem";
            this.fwaefwaefwaeToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.fwaefwaefwaeToolStripMenuItem.Text = "fwaefwaefwae";
            // 
            // fwafwafwafwaeToolStripMenuItem
            // 
            this.fwafwafwafwaeToolStripMenuItem.Name = "fwafwafwafwaeToolStripMenuItem";
            this.fwafwafwafwaeToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.fwafwafwafwaeToolStripMenuItem.Text = "fwafwafwafwae";
            // 
            // fwefwaefwfeToolStripMenuItem
            // 
            this.fwefwaefwfeToolStripMenuItem.Name = "fwefwaefwfeToolStripMenuItem";
            this.fwefwaefwfeToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.fwefwaefwfeToolStripMenuItem.Text = "fwefwaefwfe";
            // 
            // toolStripMenuItem90
            // 
            this.toolStripMenuItem90.Name = "toolStripMenuItem90";
            this.toolStripMenuItem90.Size = new System.Drawing.Size(174, 26);
            this.toolStripMenuItem90.Text = "hrdhrdhrt";
            // 
            // toolStripMenuItem91
            // 
            this.toolStripMenuItem91.Name = "toolStripMenuItem91";
            this.toolStripMenuItem91.Size = new System.Drawing.Size(165, 24);
            this.toolStripMenuItem91.Text = "hrtdhrdthrdt";
            // 
            // toolStripMenuItem92
            // 
            this.toolStripMenuItem92.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem93,
            this.toolStripMenuItem94,
            this.toolStripMenuItem95});
            this.toolStripMenuItem92.Name = "toolStripMenuItem92";
            this.toolStripMenuItem92.Size = new System.Drawing.Size(165, 24);
            this.toolStripMenuItem92.Text = "jtyjtyjtjtjt";
            // 
            // toolStripMenuItem93
            // 
            this.toolStripMenuItem93.Name = "toolStripMenuItem93";
            this.toolStripMenuItem93.Size = new System.Drawing.Size(135, 26);
            this.toolStripMenuItem93.Text = "jtyjtyjt";
            // 
            // toolStripMenuItem94
            // 
            this.toolStripMenuItem94.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fwefweaToolStripMenuItem,
            this.fweafwaefToolStripMenuItem,
            this.fwefwafwaeToolStripMenuItem,
            this.fweafwafToolStripMenuItem});
            this.toolStripMenuItem94.Name = "toolStripMenuItem94";
            this.toolStripMenuItem94.Size = new System.Drawing.Size(135, 26);
            this.toolStripMenuItem94.Text = "jtyjt";
            // 
            // fwefweaToolStripMenuItem
            // 
            this.fwefweaToolStripMenuItem.Name = "fwefweaToolStripMenuItem";
            this.fwefweaToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fwefweaToolStripMenuItem.Text = "fwefwea";
            // 
            // fweafwaefToolStripMenuItem
            // 
            this.fweafwaefToolStripMenuItem.Name = "fweafwaefToolStripMenuItem";
            this.fweafwaefToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fweafwaefToolStripMenuItem.Text = "fweafwaef";
            // 
            // fwefwafwaeToolStripMenuItem
            // 
            this.fwefwafwaeToolStripMenuItem.Name = "fwefwafwaeToolStripMenuItem";
            this.fwefwafwaeToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fwefwafwaeToolStripMenuItem.Text = "fwefwafwae";
            // 
            // fweafwafToolStripMenuItem
            // 
            this.fweafwafToolStripMenuItem.Name = "fweafwafToolStripMenuItem";
            this.fweafwafToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fweafwafToolStripMenuItem.Text = "fweafwaf";
            // 
            // toolStripMenuItem95
            // 
            this.toolStripMenuItem95.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem96,
            this.toolStripMenuItem97});
            this.toolStripMenuItem95.Name = "toolStripMenuItem95";
            this.toolStripMenuItem95.Size = new System.Drawing.Size(135, 26);
            this.toolStripMenuItem95.Text = "jtyjtty";
            // 
            // toolStripMenuItem96
            // 
            this.toolStripMenuItem96.Name = "toolStripMenuItem96";
            this.toolStripMenuItem96.Size = new System.Drawing.Size(130, 26);
            this.toolStripMenuItem96.Text = "jtyjtyj";
            // 
            // toolStripMenuItem97
            // 
            this.toolStripMenuItem97.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem98,
            this.toolStripMenuItem99,
            this.toolStripMenuItem100});
            this.toolStripMenuItem97.Name = "toolStripMenuItem97";
            this.toolStripMenuItem97.Size = new System.Drawing.Size(130, 26);
            this.toolStripMenuItem97.Text = "jtyjtyj";
            // 
            // toolStripMenuItem98
            // 
            this.toolStripMenuItem98.Name = "toolStripMenuItem98";
            this.toolStripMenuItem98.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem98.Text = "jtyjtyjt";
            // 
            // toolStripMenuItem99
            // 
            this.toolStripMenuItem99.Name = "toolStripMenuItem99";
            this.toolStripMenuItem99.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem99.Text = "jtyjtyjtyj";
            // 
            // toolStripMenuItem100
            // 
            this.toolStripMenuItem100.Name = "toolStripMenuItem100";
            this.toolStripMenuItem100.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem100.Text = "jtyjtyjjt";
            // 
            // rjTextBox1
            // 
            this.rjTextBox1.BackColor = System.Drawing.SystemColors.Window;
            this.rjTextBox1.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.rjTextBox1.BorderFocusColor = System.Drawing.Color.HotPink;
            this.rjTextBox1.BorderRadius = 0;
            this.rjTextBox1.BorderSize = 2;
            this.rjTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjTextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.rjTextBox1.Location = new System.Drawing.Point(765, 246);
            this.rjTextBox1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.rjTextBox1.Multiline = false;
            this.rjTextBox1.Name = "rjTextBox1";
            this.rjTextBox1.Padding = new System.Windows.Forms.Padding(13, 9, 13, 9);
            this.rjTextBox1.PasswordChar = false;
            this.rjTextBox1.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.rjTextBox1.PlaceholderText = "write something";
            this.rjTextBox1.Size = new System.Drawing.Size(333, 39);
            this.rjTextBox1.TabIndex = 32;
            this.rjTextBox1.Texts = "";
            this.rjTextBox1.UnderlinedStyle = false;
            // 
            // rjButton4
            // 
            this.rjButton4.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton4.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton4.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton4.BorderRadius = 0;
            this.rjButton4.BorderSize = 0;
            this.rjButton4.FlatAppearance.BorderSize = 0;
            this.rjButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton4.ForeColor = System.Drawing.Color.White;
            this.rjButton4.Location = new System.Drawing.Point(1108, 238);
            this.rjButton4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rjButton4.Name = "rjButton4";
            this.rjButton4.Size = new System.Drawing.Size(200, 49);
            this.rjButton4.TabIndex = 33;
            this.rjButton4.Text = "Show text";
            this.rjButton4.TextColor = System.Drawing.Color.White;
            this.rjButton4.UseVisualStyleBackColor = false;
            this.rjButton4.Click += new System.EventHandler(this.rjButton4_Click);
            // 
            // rjButton5
            // 
            this.rjButton5.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton5.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.rjButton5.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton5.BorderRadius = 0;
            this.rjButton5.BorderSize = 0;
            this.rjButton5.FlatAppearance.BorderSize = 0;
            this.rjButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton5.ForeColor = System.Drawing.Color.White;
            this.rjButton5.Location = new System.Drawing.Point(1108, 308);
            this.rjButton5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rjButton5.Name = "rjButton5";
            this.rjButton5.Size = new System.Drawing.Size(200, 49);
            this.rjButton5.TabIndex = 34;
            this.rjButton5.Text = "Show placeholder";
            this.rjButton5.TextColor = System.Drawing.Color.White;
            this.rjButton5.UseVisualStyleBackColor = false;
            this.rjButton5.Click += new System.EventHandler(this.rjButton5_Click);
            // 
            // rjDropdownMenu8
            // 
            this.rjDropdownMenu8.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.rjDropdownMenu8.IsMainMenu = false;
            this.rjDropdownMenu8.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox1,
            this.toolStripComboBox1,
            this.iconMenuItem1});
            this.rjDropdownMenu8.MenuItemHeight = 25;
            this.rjDropdownMenu8.MenuItemTextColor = System.Drawing.Color.Empty;
            this.rjDropdownMenu8.Name = "rjDropdownMenu8";
            this.rjDropdownMenu8.PrimaryColor = System.Drawing.Color.Empty;
            this.rjDropdownMenu8.Size = new System.Drawing.Size(215, 127);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 30);
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 31);
            // 
            // iconMenuItem1
            // 
            this.iconMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.asdfToolStripMenuItem,
            this.asdfToolStripMenuItem1});
            this.iconMenuItem1.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconMenuItem1.IconColor = System.Drawing.Color.Black;
            this.iconMenuItem1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconMenuItem1.Name = "iconMenuItem1";
            this.iconMenuItem1.Size = new System.Drawing.Size(214, 28);
            this.iconMenuItem1.Text = "iconMenuItem1";
            // 
            // asdfToolStripMenuItem
            // 
            this.asdfToolStripMenuItem.Name = "asdfToolStripMenuItem";
            this.asdfToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.asdfToolStripMenuItem.Text = "asdf";
            // 
            // asdfToolStripMenuItem1
            // 
            this.asdfToolStripMenuItem1.Name = "asdfToolStripMenuItem1";
            this.asdfToolStripMenuItem1.Size = new System.Drawing.Size(224, 28);
            this.asdfToolStripMenuItem1.Text = "asdf";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1379, 629);
            this.Controls.Add(this.rjButton5);
            this.Controls.Add(this.rjButton4);
            this.Controls.Add(this.rjTextBox1);
            this.Controls.Add(this.rjButton3);
            this.Controls.Add(this.rjButton2);
            this.Controls.Add(this.rjButton1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Custom Controls";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.rjDropdownMenu1.ResumeLayout(false);
            this.rjDropdownMenu2.ResumeLayout(false);
            this.rjDropdownMenu3.ResumeLayout(false);
            this.rjDropdownMenu4.ResumeLayout(false);
            this.rjDropdownMenu5.ResumeLayout(false);
            this.rjDropdownMenu6.ResumeLayout(false);
            this.rjDropdownMenu7.ResumeLayout(false);
            this.rjDropdownMenu8.ResumeLayout(false);
            this.rjDropdownMenu8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton iconButton7;
        private FontAwesome.Sharp.IconButton iconButton6;
        private FontAwesome.Sharp.IconButton iconButton5;
        private FontAwesome.Sharp.IconButton iconButton4;
        private FontAwesome.Sharp.IconButton iconButton3;
        private FontAwesome.Sharp.IconButton iconButton2;
        private FontAwesome.Sharp.IconButton iconButton1;
        private RJControls.RJDropdownMenu rjDropdownMenu1;
        private System.Windows.Forms.ToolStripMenuItem gergeargToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gergeragToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geargeargToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gergeargearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gergergeaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gerageargearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gergeragToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gergeragToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem gergeargToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gergegtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gegeeaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gegeagearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gegeageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gegegeaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gegeageaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gegeagToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geageagearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gegeagToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gegeageargeToolStripMenuItem;
        private RJControls.RJDropdownMenu rjDropdownMenu2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private RJControls.RJButton rjButton1;
        private RJControls.RJButton rjButton2;
        private RJControls.RJButton rjButton3;
        private RJControls.RJDropdownMenu rjDropdownMenu3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem38;
        private RJControls.RJDropdownMenu rjDropdownMenu4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem46;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem52;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem53;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem55;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem56;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem57;
        private RJControls.RJDropdownMenu rjDropdownMenu5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem58;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem59;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem60;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem61;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem62;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem63;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem64;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem65;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem66;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem67;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem68;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem69;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem70;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem71;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem72;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem73;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem74;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem75;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem76;
        private RJControls.RJDropdownMenu rjDropdownMenu6;
        private System.Windows.Forms.ToolStripMenuItem hhyrjhtyjToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtydjtdyjtdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjdyjtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjtdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrhdrhrtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrdhrdthrtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrhrdhrtdrthToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrdhrdthrToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrdhrdhrdtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrhrdhrthToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrtdhrdthrtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrtdhrdthToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrtdhrdhrtdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrdhrdhrtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hrtdhrdthrdtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjtyjtjtjtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjtyjtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjttyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjtyjToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjtyjToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem jtyjtyjtToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem jtyjtyjtyjToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jtyjtyjjtToolStripMenuItem;
        private RJControls.RJDropdownMenu rjDropdownMenu7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem77;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem78;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem79;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem80;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem81;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem82;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem83;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem84;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem85;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem86;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem87;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem88;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem89;
        private System.Windows.Forms.ToolStripMenuItem fwefwaeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fwfwaefToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fwafwafwaeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fwaefwaefwaeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fwafwafwafwaeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fwefwaefwfeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem90;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem91;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem92;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem93;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem94;
        private System.Windows.Forms.ToolStripMenuItem fwefweaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fweafwaefToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fwefwafwaeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fweafwafToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem95;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem96;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem97;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem98;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem99;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem100;
        private RJControls.RJTextBox rjTextBox1;
        private RJControls.RJButton rjButton4;
        private RJControls.RJButton rjButton5;
        private RJControls.RJDropdownMenu rjDropdownMenu8;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private FontAwesome.Sharp.IconMenuItem iconMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem asdfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asdfToolStripMenuItem1;
    }
}