﻿namespace CustomControls.Testing
{
    partial class FormRadioButton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRadioButton));
    //        this.label1 = new System.Windows.Forms.Label();
    //        this.panel1 = new System.Windows.Forms.Panel();
    //        this.rjRadioButton21 = new CustomControls.RJControls.RJRadioButton2();
    //        this.rjRadioButton22 = new CustomControls.RJControls.RJRadioButton2();
    //        this.rjRadioButton23 = new CustomControls.RJControls.RJRadioButton2();
    //        this.rjRadioButton24 = new CustomControls.RJControls.RJRadioButton2();
    //        this.rjRadioButton25 = new CustomControls.RJControls.RJRadioButton2();
    //        this.panel1.SuspendLayout();
    //        this.SuspendLayout();
    //        // 
    //        // label1
    //        // 
    //        this.label1.AutoSize = true;
    //        this.label1.Font = new System.Drawing.Font("Montserrat", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
    //        this.label1.ForeColor = System.Drawing.Color.White;
    //        this.label1.Location = new System.Drawing.Point(230, 8);
    //        this.label1.Name = "label1";
    //        this.label1.Size = new System.Drawing.Size(499, 33);
    //        this.label1.TabIndex = 0;
    //        this.label1.Text = "Custom RadioButton - C# WinForm";
    //        // 
    //        // panel1
    //        // 
    //        this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(99)))), ((int)(((byte)(177)))));
    //        this.panel1.Controls.Add(this.label1);
    //        this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
    //        this.panel1.Location = new System.Drawing.Point(0, 0);
    //        this.panel1.Name = "panel1";
    //        this.panel1.Size = new System.Drawing.Size(984, 50);
    //        this.panel1.TabIndex = 23;
    //        // 
    //        // rjRadioButton21
    //        // 
    //        this.rjRadioButton21.AutoSize = true;
    //        this.rjRadioButton21.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(151)))), ((int)(((byte)(109)))));
    //        this.rjRadioButton21.Cursor = System.Windows.Forms.Cursors.Hand;
    //        this.rjRadioButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
    //        this.rjRadioButton21.ForeColor = System.Drawing.Color.SteelBlue;
    //        this.rjRadioButton21.Location = new System.Drawing.Point(56, 95);
    //        this.rjRadioButton21.MinimumSize = new System.Drawing.Size(0, 21);
    //        this.rjRadioButton21.Name = "rjRadioButton21";
    //        this.rjRadioButton21.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
    //        this.rjRadioButton21.Size = new System.Drawing.Size(167, 35);
    //        this.rjRadioButton21.TabIndex = 25;
    //        this.rjRadioButton21.TabStop = true;
    //        this.rjRadioButton21.Text = "Option A";
    //        this.rjRadioButton21.UnCheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
    //        this.rjRadioButton21.UseVisualStyleBackColor = true;
    //        // 
    //        // rjRadioButton22
    //        // 
    //        this.rjRadioButton22.AutoSize = true;
    //        this.rjRadioButton22.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(174)))), ((int)(((byte)(217)))));
    //        this.rjRadioButton22.Cursor = System.Windows.Forms.Cursors.Hand;
    //        this.rjRadioButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
    //        this.rjRadioButton22.ForeColor = System.Drawing.Color.SteelBlue;
    //        this.rjRadioButton22.Location = new System.Drawing.Point(56, 158);
    //        this.rjRadioButton22.MinimumSize = new System.Drawing.Size(0, 21);
    //        this.rjRadioButton22.Name = "rjRadioButton22";
    //        this.rjRadioButton22.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
    //        this.rjRadioButton22.Size = new System.Drawing.Size(167, 35);
    //        this.rjRadioButton22.TabIndex = 26;
    //        this.rjRadioButton22.TabStop = true;
    //        this.rjRadioButton22.Text = "Option B";
    //        this.rjRadioButton22.UnCheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(97)))), ((int)(((byte)(255)))));
    //        this.rjRadioButton22.UseVisualStyleBackColor = true;
    //        // 
    //        // rjRadioButton23
    //        // 
    //        this.rjRadioButton23.AutoSize = true;
    //        this.rjRadioButton23.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(97)))), ((int)(((byte)(255)))));
    //        this.rjRadioButton23.Cursor = System.Windows.Forms.Cursors.Hand;
    //        this.rjRadioButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
    //        this.rjRadioButton23.ForeColor = System.Drawing.Color.SlateGray;
    //        this.rjRadioButton23.Location = new System.Drawing.Point(56, 283);
    //        this.rjRadioButton23.MinimumSize = new System.Drawing.Size(0, 21);
    //        this.rjRadioButton23.Name = "rjRadioButton23";
    //        this.rjRadioButton23.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
    //        this.rjRadioButton23.Size = new System.Drawing.Size(169, 35);
    //        this.rjRadioButton23.TabIndex = 28;
    //        this.rjRadioButton23.TabStop = true;
    //        this.rjRadioButton23.Text = "Option D";
    //        this.rjRadioButton23.UnCheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(174)))), ((int)(((byte)(217)))));
    //        this.rjRadioButton23.UseVisualStyleBackColor = true;
    //        // 
    //        // rjRadioButton24
    //        // 
    //        this.rjRadioButton24.AutoSize = true;
    //        this.rjRadioButton24.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(29)))), ((int)(((byte)(108)))));
    //        this.rjRadioButton24.Cursor = System.Windows.Forms.Cursors.Hand;
    //        this.rjRadioButton24.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
    //        this.rjRadioButton24.ForeColor = System.Drawing.Color.SlateGray;
    //        this.rjRadioButton24.Location = new System.Drawing.Point(56, 220);
    //        this.rjRadioButton24.MinimumSize = new System.Drawing.Size(0, 21);
    //        this.rjRadioButton24.Name = "rjRadioButton24";
    //        this.rjRadioButton24.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
    //        this.rjRadioButton24.Size = new System.Drawing.Size(169, 35);
    //        this.rjRadioButton24.TabIndex = 27;
    //        this.rjRadioButton24.TabStop = true;
    //        this.rjRadioButton24.Text = "Option C";
    //        this.rjRadioButton24.UnCheckedColor = System.Drawing.Color.SlateGray;
    //        this.rjRadioButton24.UseVisualStyleBackColor = true;
    //        // 
    //        // rjRadioButton25
    //        // 
    //        this.rjRadioButton25.AutoSize = true;
    //        this.rjRadioButton25.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
    //        this.rjRadioButton25.Cursor = System.Windows.Forms.Cursors.Hand;
    //        this.rjRadioButton25.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
    //        this.rjRadioButton25.ForeColor = System.Drawing.Color.DarkSlateBlue;
    //        this.rjRadioButton25.Location = new System.Drawing.Point(56, 347);
    //        this.rjRadioButton25.MinimumSize = new System.Drawing.Size(0, 21);
    //        this.rjRadioButton25.Name = "rjRadioButton25";
    //        this.rjRadioButton25.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
    //        this.rjRadioButton25.Size = new System.Drawing.Size(919, 97);
    //        this.rjRadioButton25.TabIndex = 29;
    //        this.rjRadioButton25.TabStop = true;
    //        this.rjRadioButton25.Text = "A set of well-defined, ordered and finite instructions or rules that allow\r\nan ac" +
    //"tivity to be carried out in successive steps that do not raise doubts\r\nabout who" +
    //" should carry out said activity.";
    //        this.rjRadioButton25.UnCheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(151)))), ((int)(((byte)(109)))));
    //        this.rjRadioButton25.UseVisualStyleBackColor = true;
    //        // 
    //        // FormRadioButton
    //        // 
    //        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
    //        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
    //        this.BackColor = System.Drawing.Color.WhiteSmoke;
    //        this.ClientSize = new System.Drawing.Size(984, 511);
    //        this.Controls.Add(this.rjRadioButton25);
    //        this.Controls.Add(this.rjRadioButton23);
    //        this.Controls.Add(this.rjRadioButton24);
    //        this.Controls.Add(this.rjRadioButton22);
    //        this.Controls.Add(this.rjRadioButton21);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormRadioButton";
            this.Text = "Custom Controls";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private RJControls.RJRadioButton rjRadioButton21;
        private RJControls.RJRadioButton rjRadioButton22;
        private RJControls.RJRadioButton rjRadioButton23;
        private RJControls.RJRadioButton rjRadioButton24;
        private RJControls.RJRadioButton rjRadioButton25;
    }
}