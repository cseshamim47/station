package a;

public class A
{
	private int e;
	protected int f;
	int g;
	public int h;
	public void displayE()
	{
		System.out.println("Value of e is  :"+e);
	}
	public void displayF()
	{
		System.out.println("Value of f is  :"+f);
	}
	public void displayG()
	{
		System.out.println("Value of g is  :"+g);
	}
	public void displayH()
	{
		System.out.println("Value of h is  :"+h);
	}
}