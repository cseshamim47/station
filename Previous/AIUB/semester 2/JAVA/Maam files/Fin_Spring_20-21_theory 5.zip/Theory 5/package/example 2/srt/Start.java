//package srt;
//import prs.cprs.Person;

package srt;
import prs.*;
public class Start
{
	public static void main(String args[])
	{
		Person p1=new Person();
		p1.setId(101);
		System.out.println(p1.getId());
	}
	
}