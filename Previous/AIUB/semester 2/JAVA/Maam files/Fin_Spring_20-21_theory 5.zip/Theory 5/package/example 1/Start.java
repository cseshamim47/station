import a.*;
import b.*;

public class Start 
{
	public static void main(String args[])
	{
		
		//A a1=new A();
		//a1.h=10;
		//a1.displayH();
		//a1.e=11;
		//a1.displayE();
		//B b1=new B();
		//a1.g=11;
		//a1.displayG();
		//a1.f=12;
		//a1.displayF();
		

	}
}