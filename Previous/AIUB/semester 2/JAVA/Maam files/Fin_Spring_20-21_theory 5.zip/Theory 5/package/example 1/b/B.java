package b;
import a.*;

public class B extends A
{
	public B()
	{
		f=13;
		this.displayF();
	}
}