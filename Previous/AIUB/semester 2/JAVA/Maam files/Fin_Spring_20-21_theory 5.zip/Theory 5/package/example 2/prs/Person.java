//package prs.cprs;

package prs;
public class Person
{
	private int id;
	public Person()
	{
		
	}
	public void setId(int id)
	{
		this.id=id;
	}
	public int getId()
	{
		return id;
	}
}