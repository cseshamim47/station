public class Start
{
	public static void main(String args[])
	{
		Person p1=new Person("Mashrafi",30);
		p1.showInfo();
		Person p2=new Person("shakib");
		p2.showInfo();
		p2.setAge(20);
		p2.showInfo();
		
		
	}
}