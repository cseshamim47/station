public class Start
{
	public static void main(String args[])
	{
		Teacher t1=new Teacher("Shakib",30,"Male",1000,"11-1");
		t1.showInfo();
	}
}