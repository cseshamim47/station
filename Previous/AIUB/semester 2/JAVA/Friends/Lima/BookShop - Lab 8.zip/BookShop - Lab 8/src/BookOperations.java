public interface BookOperations {
    void addQuantity(int amount);
    void sellQuantity(int amount);
}
