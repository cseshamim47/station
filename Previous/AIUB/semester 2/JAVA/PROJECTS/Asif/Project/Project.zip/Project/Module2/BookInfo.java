package Module2;
import java.lang.*;
abstract public class BookInfo
{
	public BookInfo()
	{
		
	}
	abstract void showAll();
}