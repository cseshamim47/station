<?php
//always provide a trailing slash "/" after path

define ('LIBS','libs/');
define('URL','http://localhost/matra/');
define ('APPNAME','Matra ERP');


define ('DB_TYPE','mysql');
define ('DB_HOST','localhost');
define ('DB_NAME','matradb');
define ('DB_USER','root');
define ('DB_PASS','');

//hash key used in this project wide. dont change, its important

define ('HASH_KEY', 'donotchangeitmylove');