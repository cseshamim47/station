<?php 

class Imstorereqapproval_Model extends Model{
	
	function __construct(){
		parent::__construct();
		
	}
	public function getApprovalForUser(){
		$fields = array();
		$where = "zactive = '1' and bizid = ". Session::get('sbizid') ." and xuser='". Session::get('suser') ."'" ;	
		return $this->db->select("paapproval", $fields, $where);
	}		
	public function getStoreReq(){
		$fields = array("date_format(xdate, '%d %M %Y') as xdate","ximreqnum","zemail","xappstatus", "xemail");
		$where = " bizid = ". Session::get('sbizid') ." and xappstatus in (select xstatus from paapproval where paapproval.bizid=imstorereq.bizid and paapproval.xuser='".Session::get('suser')."' and paapproval.xdept=imstorereq.xdept) and xstatus='Pending'";
		return $this->db->select("imstorereq", $fields, $where, " order by ximreqnum");
	}			
	public function getSingleReq($reqnum){
		$fields = array("*","(select xlevel from paapproval where paapproval.bizid=imstorereq.bizid and paapproval.xdept=imstorereq.xdept and paapproval.xstatus=imstorereq.xappstatus) as xlevel");
		$where = " bizid = ". Session::get('sbizid') ." and ximreqnum = '".$reqnum."' and xstatus='Pending' and xappstatus in (select xstatus from paapproval where paapproval.bizid=imstorereq.bizid and paapproval.xuser='".Session::get('suser')."' and paapproval.xdept=imstorereq.xdept)";	
		return $this->db->select("imstorereq", $fields, $where);
	}
	public function getRequisitionByNum($reqnum){
		$fields = array("`a`.`ximreqnum` as `ximreqnum`", "`b`.`xitemcode` as `xitemcode`", "(SELECT xdesc from seitem where seitem.xitemcode=b.xitemcode and seitem.bizid=b.bizid) as xdesc", "`b`.`xwh` as `xwh`", "`b`.`xqty` as `xqty`");
		$where = "`a`.`ximreqnum`=`b`.`ximreqnum` and `a`.`bizid`=`b`.`bizid` and `a`.`xstatus`='Pending' and `a`.`xappstatus` in (select xstatus from paapproval where paapproval.bizid=`a`.`bizid` and paapproval.xuser='".Session::get('suser')."' and paapproval.xdept=`a`.`xdept`) and `b`.`ximreqnum`='".$reqnum."'";	
		return $this->db->select("`imstorereq` `a` join `imstorereqdet` `b`", $fields, $where, " order by ximreqnum");
	}		
	public function getImStockDoc(){
		$fields = array();
		$where = "1=1";	
		return $this->db->select("vimtrndoc", $fields, $where);
	}
	public function getItemList($branch=""){
		$fields = array("xwh","xitemcode", "(select xdesc from seitem where vimstock.bizid=seitem.bizid and vimstock.xitemcode=seitem.xitemcode) as xdesc","xqty");
		$where = " bizid = ". Session::get('sbizid') ." and xqtypo<>0 or xqty<>0 or xqtyso<>0 $branch";	
		return $this->db->select("vimstock", $fields, $where, " order by xitemcode");
	}
	public function getApproval($dept, $level){
		$fields = array();
		$where = "zactive='1' and bizid = ". Session::get('sbizid') ." and xdept = '".$dept."' and xlevel = ".$level."" ;
		return $this->db->select("paapproval", $fields, $where);
	}
	public function confirm($postdata,$where){
		$this->db->update('imstorereq', $postdata, $where);
	}
	public function confirmConcat($updateCode,$where){
		$this->db->updateConcat('imstorereq', $updateCode, $where);
	}
}
