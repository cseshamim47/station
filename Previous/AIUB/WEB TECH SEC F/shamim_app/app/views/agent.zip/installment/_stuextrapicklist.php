<div class="panel panel-info">
	<div class="panel-heading">
		<div style="text-align: center;">
			<strong>Enrolled Students Picklist</strong>
		</div>
		<a class="btn btn-danger" href="javascrip:void(0)" onclick="window.close();">Exit</a>
	</div>
	<div class="panel-body">
		<?php echo $this->table;?>
	</div>
</div>