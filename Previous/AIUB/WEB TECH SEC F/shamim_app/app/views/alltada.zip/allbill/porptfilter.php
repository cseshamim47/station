<?php echo $this->breadcrumb; ?>
<?php echo $this->dynform;?>


<div class="panel panel-info">
            <div class="panel-body" >
				<?php echo $this->table;?>
			</div>
        </div>
</div>