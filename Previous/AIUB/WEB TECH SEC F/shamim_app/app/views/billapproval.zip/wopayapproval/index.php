          
		  <div class="panel panel-info">
            <div class="panel-heading">
                <div style="text-align: center;">
                    <h4><strong>Pending Work Order Payment List</strong></h4>
                    <div style="text-align: center; color: red;"><strong><h4 style="color:red"><?php echo $this->flag ?></h4></strong></div>
                </div>
			</div>
            <div class="panel-body" >
				<?php echo $this->table;?>
			</div>
        </div>