<div class="col-sm-12 col-md-12 main">
          
	<div class="panel panel-info">
        <div class="panel-heading">
                <div style="text-align: center;">
                    <h4><strong>Requisition Item List</strong></h4> 
                </div>
                <div class="col-md-12" style="background: #d9edf7;">
                <table class="table table-bordered table-striped table-responsive" style="width:100%">
                <tr>
                <form class="form-horizontal" name="dynamicfrm" id="dynamicfrm" action="<?php echo $this->cencelUrl ?>" method="post" enctype="multipart/form-data">
                <td>
                <input class="form-control" type="text" name="comment" placeholder="Write Modification Type...." value="" width="180"></td>
                <td>
                <input class="btn btn-warning" type="submit" value="Modify" width="10"></td>
                </form>
                </tr>
                </table>
                <a class="btn btn-info" id=""  href="<?php echo $this->backUrl ?>" role="button">Back</a>
                <a id="appbtn" class="btn btn-success" href="<?php echo $this->approveUrl ?>" role="button">Approve</a>
                <a id="delbtn" class="btn btn-danger" href="<?php echo $this->deleteUrl ?>" role="button">Delete</a>
                </div>
		</div>
        <div class="panel-body" >
        <div style="float: right;"><button class="btn btn-primary" onclick="test();" role="button"><span class="glyphicon glyphicon-print"></span>&nbsp;Print</button></div>
		<div id="printdiv">
        <div style="text-align:center;height:10.6in;width:8.3in; margin:0 auto;padding-top:30px">
            
            <div class="col-md-12">
                <?php echo $this->table ?>
            </div>
		</div>
	    
	    </div>
		</div>	  
    </div>
</div>