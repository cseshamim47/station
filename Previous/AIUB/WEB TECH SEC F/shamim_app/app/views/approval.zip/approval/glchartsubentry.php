
	<div class="row">
		 <div class="col-sm-12">
			<?php echo $this->dynform; ?>
		  </div>
		  <div class="col-sm-12">
			<div class="panel panel-info">
					<div class="panel-heading">
						<div style="text-align: center;">
							<h4><strong>Approval List</strong></h4> 
						</div>
					</div>
					<div class="panel-body" >
						<?php echo $this->table;?>
					</div>
				</div>
			</div>	
	</div>
	