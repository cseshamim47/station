$(function(){
	var dcls = "2";		
	$('#wonum').blur(function(){
		var wonum = $(this).val();
		var url = baseuri+"jsondata/getWorkOrderDetail/"+wonum;
		
		$.get(url, function(o){ 
					$('#xref').val(o[0].xref);
					$('#toname').val(o[0].toname);
					$('#toorg').val(o[0].toorg);
					$('#tomobile').val(o[0].tomobile);
					$('#xsubject').val(o[0].xsubject);
					$('#xproject').val(o[0].xproject);
					$('#toadd').val(o[0].toadd);
			}, 'json');
							
	});
});