﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myNewProject
{
    public class Parent
    {
        internal int id;
        public Parent()
        {
            Console.WriteLine("Parent public");
        }

        public void m1()
        {
            id = 10;
        }
    }
}
