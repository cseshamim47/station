﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myNewProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Parent p = new Parent();
            p.id = 10;

            Child c = new Child();
            c.id = 10;
        }
    }
}
