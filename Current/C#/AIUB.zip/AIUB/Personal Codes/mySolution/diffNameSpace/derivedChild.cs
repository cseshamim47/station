﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using myNewProject;

namespace diffNameSpace
{
    public class derivedChild : Parent
    {
        public void m1()
        {
            //derivedChild d = new derivedChild();
            //d.id = 100;

            //Parent parent = new Parent();
            //parent.id = 10;
        }
    }
}
