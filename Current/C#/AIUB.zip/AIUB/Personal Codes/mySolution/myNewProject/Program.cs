﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using myNewProject.SubFolder;

namespace myNewProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Parent p = new Parent();
            //p.id = 10;

            //Child c = new Child();
            //c.id = 10;

            //p.F1(10);
            //c.F1(10);

            //Parent ovr = new Child();

            //ovr.F1(10);

            //# ref -> converts value to reference
            //# in/out -> also works and ref
            //# params -> multi parameter
            //# default parameter valued/ optional parameter
            //# named parameter (break sequene of the parameter)


            //int a = 10, b = 20, c = 100;

            ////Console.WriteLine("a: {0}, b:{1}", a,b);

            //temp.Swap(ref a,ref b);

            //Console.WriteLine("a: {0}, b:{1}", a,b);

            //temp.M1(out c);

            //temp.M2(c:1, a:2, b:3);
            ArrayDekhacchi arrayDekhacchi = new ArrayDekhacchi();

        }
    }
}
