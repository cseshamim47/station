﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myNewProject
{
    public class Parent
    {
        internal int id;
        //public Parent()
        //{
        //    Console.WriteLine("Parent public");
        //}

        public void m1()
        {
            id = 10;
        }


        public void F1()
        {
            Console.WriteLine("parent empty F1");
        }
        
        public virtual void F1(int x)
        {
            Console.WriteLine("parent int F1 " + x);
        }

        public void F1(int x, int y)
        {
            Console.WriteLine("empty F1 " + x + y);
        }
        
        public void F1(double x, int y)
        {
            Console.WriteLine("empty F1 " + x + y);
        }
        
        public void F1(int x, double y)
        {
            Console.WriteLine("empty F1 " + x + y);
        }
    }
}
