﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppAMPro
{
    class SchoolStudent : Student
    {
        public int p;
        private int q;
        protected int r;
        internal int s;
        protected internal int t;

        private void M1()
        {
           
        }
    }
}
