﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleAppAMPro;

namespace ClassLibrary1
{
    class GradStudent : Student
    {
        public int u;
        private int v;
        protected int w;
        internal int x;
        protected internal int y;

        private void M4()
        {
            
        }
    }
}
