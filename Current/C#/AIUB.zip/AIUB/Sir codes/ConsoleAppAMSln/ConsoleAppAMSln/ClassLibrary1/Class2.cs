﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class Class2
    {
        private void M5()
        {
            GradStudent gs = new GradStudent();
        }
    }
}
