﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppStart
{
    internal class Program  // visiblity : internal, public
    {
        static void Main(string[] args)
        {


            //string s1 = Console.ReadLine();
            //int i = Convert.ToInt32(s1);
            //int j = Convert.ToInt32(Console.ReadLine());


            ////i = i + 10;

            ////input: 10

            //Console.WriteLine("i: {0}, j: {1}", i,j);
            //Console.WriteLine("ij : "+(i+j));


            float fl = 10.10F;
            double d = 10.10;
            decimal dc = 10.10M;

            int x = (int)fl;
            Console.WriteLine(x);
            











            
            
        }
    }
}
