﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_JUN_22_INHERITANCE
{
    internal class Notes
    {

    /*
    * ### INHERITANCE  
    *      # same as java
    * ### Clasification
    *      # Single inheritance
    * ### Level of inheritance 
    *      # Single Level of Inheritance ( One parent can have at most one / multiple child class ) 
    *      # Multiple Level of Inheritance 
    * 
    * ## Parent Class - Base class
    * ## Child Class - Derived class
    * ## 
    * ## Inheritance -> IS A relationship
    * ## STUDENT inherits Person
    * ## 
    * ## 
    * ##
    * ##
    * ##
    * 
    * 
    */
    }
}
